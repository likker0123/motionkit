@echo off
echo ========================================================
echo Installing MotionKit Pro Extension & Studio SFX Suite...
echo ========================================================
set TARGET=%APPDATA%\Adobe\CEP\extensions\com.motionkit.pro
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /Y /I "%~dp0com.motionkit.pro\*" "%TARGET%\"
echo.
echo ========================================================
echo Installation Complete!
echo Open After Effects or Premiere Pro -> Window -> Extensions -> MotionKit Pro
echo ========================================================
pause
