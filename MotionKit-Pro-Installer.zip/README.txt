MotionKit Pro v9.2.0 Master with 120+ Studio SFX Library.
Run Install.bat as Administrator.
Enjoy lifetime creative speed!