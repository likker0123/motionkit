Flex Glow v1.2.0

Installation:
Copy Windows/FlexGlow.aex (or macOS/FlexGlow.plugin) into:
C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\

Restart After Effects: Effect > Stylize > Flex Glow
