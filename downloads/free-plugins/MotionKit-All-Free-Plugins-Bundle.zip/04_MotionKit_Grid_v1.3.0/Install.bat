@echo off
setlocal
echo =======================================================
echo   Installing MotionKit Grid v1.3.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows-MotionKitGrid.aex" (
    copy /Y "%~dp0Windows-MotionKitGrid.aex" "%DEST%\MotionKitGrid.aex" >nul
    echo [OK] Installed MotionKitGrid.aex into %DEST%
) else if exist "%~dp0MotionKitGrid.aex" (
    copy /Y "%~dp0MotionKitGrid.aex" "%DEST%\MotionKitGrid.aex" >nul
    echo [OK] Installed MotionKitGrid.aex into %DEST%
) else (
    echo [ERROR] MotionKitGrid.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > MotionKit > MotionKit Grid
echo.
pause
