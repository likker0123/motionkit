/**
 * Pure helpers shared by the service worker and the popup, kept free of
 * chrome.* so they can be tested in Node.
 */
export const HOST_NAME = 'in.captureflex.flexdl';

export const DEFAULTS = Object.freeze({
  enabled: true,
  types: { video: true, audio: true, compressed: true, programs: true, documents: true, images: false, other: true },
  minSizeKB: 0,                 // 0 = any size
  skipHosts: [],                // "example.com" entries never captured
  notify: true
});

const EXT = {
  video: ['mp4', 'mov', 'mkv', 'webm', 'avi', 'm4v', 'mpg', 'mpeg', 'wmv', 'flv', 'ts', 'mts', 'm2ts', '3gp', 'mxf'],
  audio: ['mp3', 'm4a', 'aac', 'wav', 'flac', 'ogg', 'opus', 'aiff', 'aif', 'wma'],
  images: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'heic', 'bmp', 'tif', 'tiff', 'svg', 'psd', 'exr'],
  documents: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'csv', 'epub', 'srt', 'vtt'],
  compressed: ['zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'zst', 'iso', 'dmg'],
  programs: ['exe', 'msi', 'pkg', 'deb', 'rpm', 'apk', 'appimage', 'zxp', 'aex', 'prm']
};
const INDEX = new Map(); for (const [t, list] of Object.entries(EXT)) for (const e of list) INDEX.set(e, t);

export function extensionOf(name) {
  const base = String(name || '').split(/[\\/]/).pop().split(/[?#]/)[0];
  return base.includes('.') ? base.slice(base.lastIndexOf('.') + 1).toLowerCase() : '';
}
export function typeOf(name, mime) {
  const t = INDEX.get(extensionOf(name));
  if (t) return t;
  const m = String(mime || '').toLowerCase();
  if (m.startsWith('video/')) return 'video';
  if (m.startsWith('audio/')) return 'audio';
  if (m.startsWith('image/')) return 'images';
  if (m.startsWith('text/') || /pdf|officedocument|msword/.test(m)) return 'documents';
  if (/zip|rar|7z|tar|gzip|compressed/.test(m)) return 'compressed';
  if (/octet-stream|msdownload|executable/.test(m)) return 'programs';
  return 'other';
}
export function hostOf(url) { try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }

/**
 * Should this browser download be taken over? item = { url, filename, mime,
 * fileSize, referrer }. Blob and data URLs are the page's own creations and
 * stay in the browser; so do sites the user excluded and types they turned off.
 */
export function shouldCapture(item, settings = DEFAULTS) {
  const s = { ...DEFAULTS, ...(settings || {}), types: { ...DEFAULTS.types, ...((settings && settings.types) || {}) } };
  if (!s.enabled) return { capture: false, reason: 'off' };
  const url = String(item.url || '');
  if (/^flexdl:/i.test(url)) return { capture: false, reason: 'own' };
  if (!/^https?:\/\//i.test(url)) return { capture: false, reason: 'not-http' };
  const host = hostOf(url);
  if ((s.skipHosts || []).some((h) => host === h || host.endsWith('.' + h))) return { capture: false, reason: 'skipped-host' };
  const type = typeOf(item.filename || url, item.mime);
  if (s.types[type] === false) return { capture: false, reason: 'type-off', type };
  const size = Number(item.fileSize);
  if (s.minSizeKB > 0 && size > 0 && size < s.minSizeKB * 1024) return { capture: false, reason: 'small', type };
  return { capture: true, type };
}

/**
 * The same URL captured again within `windowMs` is the page firing twice or the
 * browser retrying the download we cancelled - one capture, not two.
 * `recent` is a Map url → timestamp the caller keeps.
 */
export function isRecentDuplicate(recent, url, now = Date.now(), windowMs = 15000) {
  const key = String(url || '').split('#')[0];
  const last = recent.get(key);
  for (const [k, t] of recent) if (now - t > windowMs) recent.delete(k);
  recent.set(key, now);
  return last !== undefined && now - last <= windowMs;
}

/** "name=value; name2=value2" from the cookie objects chrome.cookies returns. */
export function cookieHeader(cookies) {
  return (cookies || []).filter((c) => c && c.name).map((c) => c.name + '=' + c.value).join('; ');
}

/** The message sent to the app over native messaging. */
export function buildMessage(item, { cookies = '', userAgent = '', browser = 'chrome' } = {}) {
  return {
    type: 'download',
    url: item.url,
    filename: item.filename || '',
    title: item.title || item.filename || '',
    mime: item.mime || '',
    size: Number(item.fileSize) > 0 ? Number(item.fileSize) : null,
    referrer: item.referrer || '',
    cookies, userAgent, browser,
    direct: true
  };
}

/**
 * The app could not fetch something (a site that only answers its own browser
 * tab). Work out what the extension should do: let the browser download it,
 * remember not to capture that site again, and never loop on the same URL.
 */
export function planHandbacks(items, settings = DEFAULTS, handedBack = new Set()) {
  const skip = new Set(settings.skipHosts || []);
  const urls = [];
  for (const item of items || []) {
    const url = item && item.url;
    if (!url || handedBack.has(url) || !/^https?:\/\//i.test(url)) continue;
    urls.push(url);
    const host = hostOf(url);
    if (host) skip.add(host);
  }
  return { urls, skipHosts: Array.from(skip), changed: urls.length > 0 };
}

/** Fallback when the app's native host is not registered: the flexdl:// link. */
export function flexdlUrl(item) {
  const q = new URLSearchParams();
  q.set('url', item.url);
  q.set('direct', '1');
  q.set('source', 'browser');
  if (item.filename) q.set('filename', item.filename);
  if (item.referrer) q.set('referrer', item.referrer);
  if (item.title) q.set('title', String(item.title).slice(0, 120));
  return 'flexdl://download?' + q.toString();
}
