import { DEFAULTS, hostOf } from './lib.js';

const $ = (id) => document.getElementById(id);
const TYPES = [['video', 'Video'], ['audio', 'Audio'], ['compressed', 'Archives'], ['programs', 'Programs'], ['documents', 'Documents'], ['images', 'Images'], ['other', 'Everything else']];
let settings = { ...DEFAULTS };

async function load() {
  const s = await chrome.storage.sync.get('settings');
  settings = { ...DEFAULTS, ...(s.settings || {}), types: { ...DEFAULTS.types, ...((s.settings && s.settings.types) || {}) } };
  paint();
  const { count = 0 } = await chrome.storage.local.get('count');
  $('count').textContent = String(count);
  chrome.runtime.sendMessage({ type: 'ping-app' }, (r) => {
    const el = $('app');
    if (r && r.ok) { el.textContent = 'app ' + (r.version ? 'v' + r.version : 'connected'); el.className = 'app ok'; }
    else { el.textContent = 'app not found'; el.className = 'app warn'; el.title = 'Install Flex Downloader from captureflex.in and open it once.'; }
  });
}
function save() { chrome.storage.sync.set({ settings }); }
function paint() {
  $('enabled').classList.toggle('on', !!settings.enabled);
  $('min').value = String(Math.round((settings.minSizeKB || 0) / 1024));
  const box = $('types'); box.innerHTML = '';
  for (const [key, label] of TYPES) {
    const l = document.createElement('label'); l.className = 'chip';
    const c = document.createElement('input'); c.type = 'checkbox'; c.checked = settings.types[key] !== false;
    c.addEventListener('change', () => { settings.types[key] = c.checked; save(); });
    l.appendChild(c); l.appendChild(document.createTextNode(label)); box.appendChild(l);
  }
}
$('enabled').addEventListener('click', () => { settings.enabled = !settings.enabled; save(); paint(); });
$('min').addEventListener('change', () => { settings.minSizeKB = Math.max(0, Math.round(Number($('min').value) || 0)) * 1024; save(); });
$('send').addEventListener('click', () => {
  const url = $('url').value.trim(); if (!/^https?:\/\//i.test(url)) { $('url').focus(); return; }
  chrome.runtime.sendMessage({ type: 'send-url', url }, () => { $('url').value = ''; });
});
$('url').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('send').click(); });
$('skip').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = hostOf(tab && tab.url || ''); if (!host) return;
  settings.skipHosts = Array.from(new Set([...(settings.skipHosts || []), host])); save();
  $('skip').textContent = 'Skipping ' + host;
});
$('site').addEventListener('click', () => chrome.tabs.create({ url: 'https://captureflex.in' }));
load();
