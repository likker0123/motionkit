/**
 * Flex Downloader - browser extension service worker.
 *
 * Every download the browser is about to start passes through here. If the
 * user wants it captured, the browser's own download is cancelled before it
 * writes a byte and the link goes to the Flex Downloader app - with the
 * page's cookies and referrer, so files behind a login still come down - and
 * the app fetches it over many parallel connections.
 *
 * The app is reached over native messaging (no prompts, cookies travel).
 * When the app has not registered its host yet, the flexdl:// link is opened
 * instead, which the browser confirms once.
 */
import { HOST_NAME, DEFAULTS, shouldCapture, cookieHeader, buildMessage, flexdlUrl, hostOf, isRecentDuplicate, planHandbacks } from './lib.js';

const MENU_ID = 'flexdl-download';
const captured = new Set();          // download ids we cancelled ourselves
const recent = new Map();            // url → when it was last sent, to swallow repeats
const handedBack = new Set();        // urls the app gave back: the browser owns those
let settingsCache = null;

async function settings() {
  if (settingsCache) return settingsCache;
  const s = await chrome.storage.sync.get('settings');
  settingsCache = { ...DEFAULTS, ...(s.settings || {}), types: { ...DEFAULTS.types, ...((s.settings && s.settings.types) || {}) } };
  return settingsCache;
}
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'sync' && changes.settings) settingsCache = null; });

async function sendToApp(item) {
  const s = await settings();
  let cookies = '';
  try { cookies = cookieHeader(await chrome.cookies.getAll({ url: item.url })); } catch (e) { }
  const msg = buildMessage(item, { cookies, userAgent: navigator.userAgent, browser: browserName() });
  try {
    const reply = await chrome.runtime.sendNativeMessage(HOST_NAME, msg);
    if (reply && reply.ok) { await bump(); if (s.notify) note('Sent to Flex Downloader', item.filename || item.url); return true; }
    throw new Error(reply && reply.error || 'no reply');
  } catch (e) {
    //  Host not registered (the app never ran, or an old version): fall back to the link.
    try {
      const tab = await chrome.tabs.create({ url: flexdlUrl(item), active: false });
      setTimeout(() => chrome.tabs.remove(tab.id).catch(() => { }), 2500);
      await bump();
      if (s.notify) note('Sent to Flex Downloader', (item.filename || item.url) + '\nOpen the app once so cookies can travel too.');
      return true;
    } catch (e2) {
      note('Flex Downloader is not installed', 'Get it at captureflex.in. This download stayed in the browser.');
      return false;
    }
  }
}

function browserName() {
  const ua = navigator.userAgent;
  if (/Edg\//.test(ua)) return 'edge';
  if (/Brave/.test(ua) || (navigator.brave)) return 'brave';
  if (/Vivaldi/.test(ua)) return 'vivaldi';
  if (/OPR\//.test(ua)) return 'opera';
  return 'chrome';
}
function note(title, message) {
  try { chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title, message: String(message).slice(0, 200) }); } catch (e) { }
}
async function bump() {
  const { count = 0 } = await chrome.storage.local.get('count');
  await chrome.storage.local.set({ count: count + 1 });
  chrome.action.setBadgeBackgroundColor({ color: '#00ff66' });
  chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ color: '#000000' });
  chrome.action.setBadgeText({ text: String(count + 1) });
}

/*  The browser tells us the file name and type here, before anything is
    written - the one moment a download can be taken over cleanly. */
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  (async () => {
    if (captured.has(item.id)) return;
    if (item.byExtensionId === chrome.runtime.id) return;               // our own fallback tab
    if (handedBack.has(item.finalUrl || item.url)) return;              // the app gave this one back: let it through
    const s = await settings();
    const verdict = shouldCapture({ url: item.finalUrl || item.url, filename: item.filename, mime: item.mime, fileSize: item.fileSize, referrer: item.referrer }, s);
    if (!verdict.capture) return;
    captured.add(item.id);
    try { await chrome.downloads.cancel(item.id); } catch (e) { }
    try { await chrome.downloads.erase({ id: item.id }); } catch (e) { }
    if (isRecentDuplicate(recent, item.finalUrl || item.url)) return;           // the page fired twice: one download
    await sendToApp({ url: item.finalUrl || item.url, filename: item.filename, mime: item.mime, fileSize: item.fileSize, referrer: item.referrer, title: item.filename });
    setTimeout(collectHandbacks, 6000);      // did the app manage it, or is it coming back?
  })();
  suggest();
  return true;
});

/*  Some sites (Cloudflare's challenge, mostly) only serve the browser tab that
    solved their check: no cookie or user agent gets the app past it. The app
    says so, and the browser quietly finishes those downloads itself - and the
    site is added to the never-capture list so it does not happen twice. */
async function collectHandbacks() {
  let reply = null;
  try { reply = await chrome.runtime.sendNativeMessage(HOST_NAME, { type: 'handbacks' }); } catch (e) { return; }
  const items = (reply && reply.items) || [];
  if (!items.length) return;
  const s = await settings();
  const plan = planHandbacks(items, s, handedBack);
  if (!plan.changed) return;
  for (const url of plan.urls) handedBack.add(url);
  settingsCache = { ...s, skipHosts: plan.skipHosts };
  await chrome.storage.sync.set({ settings: settingsCache });
  for (const url of plan.urls) {
    try { await chrome.downloads.download({ url }); } catch (e) { }
  }
  const host = hostOf(plan.urls[0]) || 'that site';
  note('Your browser is finishing this one', host + ' only lets its own tab download. Flex Downloader will leave ' + host + ' to the browser from now on.');
}
chrome.alarms.create('flexdl-handbacks', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'flexdl-handbacks') collectHandbacks(); });

/* ── right-click: Download with Flex Downloader ─────────────────────── */
chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({ id: MENU_ID, title: 'Download with Flex Downloader', contexts: ['link', 'video', 'audio', 'image', 'page'] });
  const s = await chrome.storage.sync.get('settings');
  if (!s.settings) await chrome.storage.sync.set({ settings: DEFAULTS });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID) return;
  const url = info.linkUrl || info.srcUrl || info.pageUrl;
  if (!url) return;
  //  A page link (YouTube, Instagram…) goes as a page: the app resolves it.
  //  A file link goes as a file, with cookies, like a captured download.
  const isFile = /\.(mp4|mov|mkv|webm|m4v|mp3|m4a|wav|flac|zip|rar|7z|pdf|exe|dmg|pkg|msi|jpg|jpeg|png|gif|webp)(\?|#|$)/i.test(url) || !!info.srcUrl;
  if (isFile) sendToApp({ url, filename: '', mime: '', fileSize: 0, referrer: info.pageUrl || '', title: tab && tab.title });
  else {
    const q = new URLSearchParams({ url, source: 'browser', title: (tab && tab.title || '').slice(0, 120) });
    chrome.tabs.create({ url: 'flexdl://download?' + q.toString(), active: false }).then((t) => setTimeout(() => chrome.tabs.remove(t.id).catch(() => { }), 2500));
  }
});

/* ── the popup asks: is the app there? ──────────────────────────────── */
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === 'ping-app') {
    chrome.runtime.sendNativeMessage(HOST_NAME, { type: 'ping' }).then((r) => reply({ ok: !!(r && r.ok), version: r && r.version || '' }), (e) => reply({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (msg && msg.type === 'send-url' && msg.url) {
    sendToApp({ url: msg.url, filename: '', mime: '', fileSize: 0, referrer: '', title: '' }).then((ok) => reply({ ok }));
    return true;
  }
  return false;
});
