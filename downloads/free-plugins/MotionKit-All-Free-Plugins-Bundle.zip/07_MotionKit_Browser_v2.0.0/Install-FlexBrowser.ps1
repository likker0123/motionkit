<#
    Install-FlexBrowser.ps1 — the Windows counterpart of FlexBrowser-<ver>.pkg.

    ONE installation, both hosts:

      FlexBrowser.aex + WebView2Loader.dll
          -> C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\
             the docked After Effects panel (Window > FlexBrowser)

      FlexBrowser.exe + WebView2Loader.dll
          -> C:\Program Files\FlexBrowser\           (elevated: all users)
          -> %LOCALAPPDATA%\Programs\FlexBrowser\    (not elevated: this user)
             the same browser as a window, which Flex ULTIMATE opens for
             Premiere Pro — Premiere cannot load AEGP plugins at all.

    Both destinations are exactly the two paths the Flex panels look in, in that
    order. Installing machine-wide when elevated is deliberate: UAC elevation by
    a DIFFERENT administrator account would otherwise put the app in that
    account's profile, where the signed-in user could never reach it.

    Run by right-clicking "Install FlexBrowser.bat" > Run as administrator, or:
        powershell -ExecutionPolicy Bypass -File .\Install-FlexBrowser.ps1

    Without elevation the Premiere half still installs and the script says what
    it skipped.
#>
[CmdletBinding()]
param(
    [switch]$Uninstall
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

$mediaCore  = Join-Path $env:ProgramFiles 'Adobe\Common\Plug-ins\7.0\MediaCore'
$appDirAll  = Join-Path $env:ProgramFiles 'FlexBrowser'
$appDirUser = Join-Path $env:LOCALAPPDATA 'Programs\FlexBrowser'

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal $id).IsInRole(
        [Security.Principal.WindowsBuiltinRole]::Administrator)
}
function Write-Step($msg) { Write-Host "  $msg" }

$admin = Test-Admin
Write-Host ''
Write-Host 'FlexBrowser' -ForegroundColor Green
Write-Host '-----------'

# --------------------------------------------------------------- uninstall --
if ($Uninstall) {
    if ($admin) {
        foreach ($f in 'FlexBrowser.aex', 'WebView2Loader.dll') {
            $p = Join-Path $mediaCore $f
            if (Test-Path $p) { Remove-Item $p -Force; Write-Step "removed $p" }
        }
        if (Test-Path $appDirAll) { Remove-Item $appDirAll -Recurse -Force; Write-Step "removed $appDirAll" }
    } else {
        Write-Warning 'Not elevated — the After Effects plug-in and the all-users app were left in place.'
    }
    if (Test-Path $appDirUser) { Remove-Item $appDirUser -Recurse -Force; Write-Step "removed $appDirUser" }
    $lnk = Join-Path ([Environment]::GetFolderPath('Programs')) 'FlexBrowser.lnk'
    if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Step "removed $lnk" }
    Write-Host ''
    Write-Host 'FlexBrowser removed. Restart After Effects.' -ForegroundColor Green
    Write-Host ''
    exit 0
}

foreach ($f in 'FlexBrowser.aex', 'FlexBrowser.exe', 'WebView2Loader.dll') {
    if (-not (Test-Path (Join-Path $here $f))) {
        throw "$f is missing from $here — run this script from the folder it shipped in."
    }
}

# ------------------------------------------ 1. the After Effects panel -----
$aeInstalled = $false
if ($admin) {
    New-Item -ItemType Directory -Force -Path $mediaCore | Out-Null
    Copy-Item (Join-Path $here 'FlexBrowser.aex')    $mediaCore -Force
    Copy-Item (Join-Path $here 'WebView2Loader.dll') $mediaCore -Force
    Write-Step "After Effects panel  -> $mediaCore"
    $aeInstalled = $true
} else {
    Write-Warning 'Not running as administrator — skipping the After Effects panel.'
    Write-Warning 'Right-click "Install FlexBrowser.bat" and choose "Run as administrator" for that half.'
}

# ------------------------------------- 2. the app, for Premiere Pro --------
$appDir = if ($admin) { $appDirAll } else { $appDirUser }
New-Item -ItemType Directory -Force -Path $appDir | Out-Null
Copy-Item (Join-Path $here 'FlexBrowser.exe')    $appDir -Force
Copy-Item (Join-Path $here 'WebView2Loader.dll') $appDir -Force
Write-Step ("FlexBrowser app      -> $appDir" + $(if ($admin) { '  (all users)' } else { '  (this user)' }))

# A stale per-user copy would win the panel's lookup over a newer all-users one.
if ($admin -and (Test-Path (Join-Path $appDirUser 'FlexBrowser.exe'))) {
    Remove-Item $appDirUser -Recurse -Force
    Write-Step "removed the older per-user copy at $appDirUser"
}

try {
    $lnk = Join-Path ([Environment]::GetFolderPath('Programs')) 'FlexBrowser.lnk'
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
    $s.TargetPath = Join-Path $appDir 'FlexBrowser.exe'
    $s.WorkingDirectory = $appDir
    $s.Description = 'FlexBrowser — the web, beside your editor'
    $s.Save()
    Write-Step "Start menu shortcut  -> $lnk"
} catch {
    Write-Warning "Could not create the Start-menu shortcut: $($_.Exception.Message)"
}

# ------------------------------- 3. the WebView2 Runtime both halves need --
$rtKeys = @(
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
)
$rt = $rtKeys | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($rt) {
    Write-Step "WebView2 Runtime     -> found ($((Get-ItemProperty $rt).pv))"
} else {
    Write-Host ''
    Write-Warning 'The Microsoft Edge WebView2 Runtime was not found.'
    Write-Warning 'FlexBrowser needs it to render pages. Install the Evergreen Runtime from:'
    Write-Warning '  https://developer.microsoft.com/microsoft-edge/webview2/'
}

Write-Host ''
Write-Host 'Done.' -ForegroundColor Green
if ($aeInstalled) { Write-Host '  Restart After Effects, then Window > FlexBrowser.' }
Write-Host '  In Premiere Pro: Flex ULTIMATE > Editors > FLEXBROWSER > OPEN FLEXBROWSER.'
Write-Host ''
