FlexBrowser 2.0.0 — Windows
=========================================

A real web browser inside your editor. Pexels, Unsplash, Google, Instagram and
YouTube all load and you stay signed in, because pages open as real browser
documents rather than embedded frames.


INSTALL
-------
Right-click "Install FlexBrowser.bat" and choose "Run as administrator".

That installs both halves at once:

  After Effects   a docked panel.  Restart After Effects, then Window >
                  FlexBrowser.

  Premiere Pro    the FlexBrowser app.  Open it from Flex ULTIMATE >
                  Editors > FLEXBROWSER, or from the Start menu. Premiere
                  cannot host native panels, so this is a window instead —
                  turn on Window > Float on Top to keep it over Premiere.


REQUIREMENTS
------------
The Microsoft Edge WebView2 Runtime. It is already on Windows 11 and on any
machine with a current Edge. The installer checks and tells you if it is
missing:  https://developer.microsoft.com/microsoft-edge/webview2/


IF SOMETHING GOES WRONG
-----------------------
FlexBrowser writes a log to your Desktop as FlexBrowser.log. It records what
happened at startup, which is usually enough to say why a panel came up empty.


UNINSTALL
---------
Run this from an administrator PowerShell in this folder:

    powershell -ExecutionPolicy Bypass -File .\Install-FlexBrowser.ps1 -Uninstall
