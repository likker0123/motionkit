@echo off
REM ---------------------------------------------------------------------------
REM  FlexBrowser installer launcher.
REM
REM  Right-click this file and choose "Run as administrator".
REM
REM  The After Effects plug-in goes to Program Files and needs administrator
REM  rights. The FlexBrowser app (the Premiere Pro half) installs either way:
REM  elevated it goes to C:\Program Files\FlexBrowser for every user, and
REM  without elevation to this user's AppData. Both are paths the Flex panels
REM  already look in.
REM ---------------------------------------------------------------------------
setlocal
set "HERE=%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 goto elevate

powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%Install-FlexBrowser.ps1"
pause
exit /b

:elevate
echo Requesting administrator rights for the After Effects plug-in...
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b
