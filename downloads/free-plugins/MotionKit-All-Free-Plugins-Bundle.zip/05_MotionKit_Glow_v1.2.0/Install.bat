@echo off
setlocal
echo =======================================================
echo   Installing MotionKit Glow v1.2.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0MotionKitGlow.aex" (
    copy /Y "%~dp0MotionKitGlow.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitGlow.aex into %DEST%
) else (
    echo [ERROR] MotionKitGlow.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Stylize > MotionKit Glow
echo.
pause
