#!/bin/bash
# Flex Command Console installer for macOS - After Effects.
cd "$(dirname "$0")" || exit 1
P="$PWD/payload/FlexSwitcher.plugin"
MEDIACORE="/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore"
DEST="$MEDIACORE/FlexSwitcher.plugin"
clear
echo "  Flex Command Console - installer"
echo "  --------------------------------"
[ -d "$P" ] || { echo "  The 'payload' folder is missing. Unzip the whole download and run this from inside it."; read -r -p "  Press Return to close. " _; exit 1; }

while pgrep -qf "After Effects.*/Contents/MacOS/After Effects"; do
  echo
  echo "  After Effects is open. It only looks for plug-ins when it starts,"
  echo "  so please quit it (Cmd-Q) first."
  read -r -p "  Press Return when it is closed... " _
done

echo
echo "  After Effects' plug-in folder belongs to the system, so macOS will ask for"
echo "  your password (the one you log in to this Mac with; nothing shows as you type)."
# After Effects loads EVERY copy it finds - an older one left behind means every
# Flex command twice and two consoles on one shortcut. Older copies are removed,
# wherever earlier versions of this installer or a manual install put them.
OLD=("$MEDIACORE/FlexSwitcher.plugin" "$MEDIACORE/FlexSwitcher.bundle" "$MEDIACORE/Flex Console v2.6.bundle")
for APP in /Applications/Adobe\ After\ Effects*; do
  [ -d "$APP/Plug-ins" ] && OLD+=("$APP/Plug-ins/FlexSwitcher.plugin" "$APP/Plug-ins/FlexSwitcher.bundle")
done
sudo mkdir -p "$MEDIACORE" || { echo "  NOT installed (password cancelled?). Run this again to retry."; read -r -p "  Press Return to close. " _; exit 1; }
for O in "${OLD[@]}"; do [ -e "$O" ] && sudo rm -rf "$O"; done
sudo ditto "$P" "$DEST" && sudo xattr -dr com.apple.quarantine "$DEST" 2>/dev/null

echo
if [ -d "$DEST" ]; then
  echo "  Installed."
  echo
  echo "  Start After Effects, then:"
  echo "    1. Edit > Keyboard Shortcuts, search for  Flex: Command Console  and give it a key"
  echo "       (many people use  Shift+Space  or  Ctrl+Space)."
  echo "    2. Press it. Type  help  to see everything it can do."
  echo "  The small label under the Paste button should read v2.7."
else
  echo "  NOT installed. Run this again to retry, or copy  payload/FlexSwitcher.plugin  into"
  echo "  $MEDIACORE  by hand (see README.txt)."
fi
echo
read -r -p "  Press Return to close. " _
