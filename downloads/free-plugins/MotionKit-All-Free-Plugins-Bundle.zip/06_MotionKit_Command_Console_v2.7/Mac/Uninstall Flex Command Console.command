#!/bin/bash
# Removes Flex Command Console from After Effects (macOS).
MEDIACORE="/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore"
clear
echo "  Flex Command Console - uninstall"
echo "  --------------------------------"
while pgrep -qf "After Effects.*/Contents/MacOS/After Effects"; do
  echo "  Please quit After Effects first."; read -r -p "  Press Return when it is closed... " _
done
echo "  macOS will ask for your password."
OLD=("$MEDIACORE/FlexSwitcher.plugin" "$MEDIACORE/FlexSwitcher.bundle" "$MEDIACORE/Flex Console v2.6.bundle")
for APP in /Applications/Adobe\ After\ Effects*; do
  [ -d "$APP/Plug-ins" ] && OLD+=("$APP/Plug-ins/FlexSwitcher.plugin" "$APP/Plug-ins/FlexSwitcher.bundle")
done
N=0; for O in "${OLD[@]}"; do [ -e "$O" ] && sudo rm -rf "$O" && N=$((N+1)); done
echo
echo "  Removed $N cop$([ $N = 1 ] && echo y || echo ies)."
echo "  Your recent commands, macros and shortcuts were kept in"
echo "  ~/Library/Application Support/FlexSwitcher  - delete that folder too if you will not come back."
echo
read -r -p "  Press Return to close. " _
