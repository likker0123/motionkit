@echo off
title Flex Command Console - Uninstall
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0payload\install.ps1" -Uninstall
echo.
pause
