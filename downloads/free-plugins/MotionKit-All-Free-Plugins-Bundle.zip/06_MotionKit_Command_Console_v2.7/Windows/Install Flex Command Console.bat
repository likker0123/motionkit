@echo off
title Flex Command Console - Install
echo.
echo   Flex Command Console for After Effects
echo   --------------------------------------
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0payload\install.ps1"
echo.
pause
