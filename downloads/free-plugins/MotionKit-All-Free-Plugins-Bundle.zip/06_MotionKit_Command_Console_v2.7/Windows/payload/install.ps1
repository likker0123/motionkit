# Flex Command Console for Windows - copies FlexSwitcher.aex into the Plug-ins folder of
# every After Effects on this computer. Those folders live under Program Files, so
# Windows asks for administrator rights once.
param([switch]$Uninstall, [switch]$Elevated)
$ErrorActionPreference = 'Stop'
$self = $MyInvocation.MyCommand.Path
$here = Split-Path -Parent $self
$aex  = Join-Path $here 'FlexSwitcher.aex'

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Every "...\Support Files\Plug-ins" of an installed After Effects: what the registry
# says, plus a look under Program Files for anything the registry does not mention.
function Get-PluginFolders {
  $found = @()
  $key = 'HKLM:\SOFTWARE\Adobe\After Effects'
  if (Test-Path $key) {
    foreach ($ver in Get-ChildItem $key -ErrorAction SilentlyContinue) {
      $p = (Get-ItemProperty $ver.PSPath -ErrorAction SilentlyContinue).InstallPath
      if ($p) { $found += (Join-Path $p 'Plug-ins') }
    }
  }
  foreach ($root in @($env:ProgramFiles, 'C:\Adobe')) {
    if ($root -and (Test-Path (Join-Path $root 'Adobe'))) { $root = Join-Path $root 'Adobe' }
    if ($root -and (Test-Path $root)) {
      foreach ($d in Get-ChildItem $root -Directory -Filter 'Adobe After Effects*' -ErrorAction SilentlyContinue) {
        $found += (Join-Path $d.FullName 'Support Files\Plug-ins')
      }
    }
  }
  return @($found | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | ForEach-Object { (Resolve-Path -LiteralPath $_).Path.TrimEnd('\') } | Sort-Object -Unique)
}

try {
  if (-not $Uninstall -and -not (Test-Path -LiteralPath $aex)) {
    throw "FlexSwitcher.aex is missing next to this script. Unzip the whole download first, then run the installer from the unzipped folder."
  }
  while (@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'AfterFX*' }).Count -gt 0) {
    Write-Host '  Please quit After Effects first: it only looks for plug-ins when it starts.' -ForegroundColor Yellow
    Read-Host '  Press Enter when it is closed' | Out-Null
  }

  if (-not (Test-Admin)) {
    if ($Elevated) { throw 'Administrator rights were not granted.' }
    Write-Host '  Windows will now ask for permission: the After Effects folder is under Program Files.'
    $args2 = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $self + '"'), '-Elevated')
    if ($Uninstall) { $args2 += '-Uninstall' }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $args2 -Verb RunAs -Wait
    exit 0
  }

  $folders = Get-PluginFolders
  if ($folders.Count -eq 0) {
    throw "No After Effects was found. Copy FlexSwitcher.aex by hand into  <After Effects>\Support Files\Plug-ins\  (see README.txt)."
  }

  # After Effects loads EVERY copy it finds: one left in the shared MediaCore folder
  # would mean every Flex command twice. It is renamed, not deleted.
  $shared = Join-Path $env:ProgramFiles 'Adobe\Common\Plug-ins\7.0\MediaCore\FlexSwitcher.aex'
  if (Test-Path -LiteralPath $shared) {
    Move-Item -LiteralPath $shared -Destination ($shared + '.old') -Force
    Write-Host '  An older copy in the shared MediaCore folder was renamed to FlexSwitcher.aex.old'
  }

  foreach ($f in $folders) {
    $target = Join-Path $f 'FlexSwitcher.aex'
    if ($Uninstall) {
      if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force; Write-Host ('  Removed from  ' + $f) -ForegroundColor Green }
    } else {
      Copy-Item -LiteralPath $aex -Destination $target -Force
      Unblock-File -LiteralPath $target -ErrorAction SilentlyContinue
      Write-Host ('  Installed into  ' + $f) -ForegroundColor Green
    }
  }

  Write-Host ''
  if ($Uninstall) {
    Write-Host '  Your recent commands, macros and shortcuts were kept in  %APPDATA%\FlexSwitcher .'
  } else {
    Write-Host '  Next: start After Effects, open  Edit > Keyboard Shortcuts , search for'
    Write-Host '  "Flex: Command Console" and give it a key. Press it, then type  help .'
    Write-Host '  The small label under the tool buttons should read v2.7.'
  }
} catch {
  Write-Host ''
  Write-Host ('  Could not finish: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Nothing else on your computer was changed. Write to support@captureflex.in with this message.'
  if ($Elevated) { Read-Host '  Press Enter to close' | Out-Null }
  exit 1
}
if ($Elevated) { Write-Host ''; Read-Host '  Press Enter to close' | Out-Null }
