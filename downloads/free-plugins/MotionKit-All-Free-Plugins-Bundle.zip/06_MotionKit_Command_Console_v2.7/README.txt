FLEX COMMAND CONSOLE 2.7 — After Effects, macOS + Windows
================================================================

A command bar for After Effects. Press your shortcut, type what you want, hit
Enter:   deepglow red  ·  blur 50  ·  stagger 3  ·  ease 80  ·  solid red

What is new in this version:  WHAT'S NEW.txt
Every command, with examples: Command Reference.html  (opens in any browser)
                              or type  help  inside the console.


INSTALL — macOS  (macOS 11 or later, Apple silicon and Intel)
----------------------------------------------------------------
1. Quit After Effects.
2. Open the  Mac  folder and double-click  "Install Flex Command Console.command".
   macOS asks for your Mac password once: After Effects' plug-in folder belongs
   to the system. Older copies of the console are removed for you.
3. Start After Effects.

   By hand instead: in Finder choose Go > Go to Folder…, paste
     /Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/
   and drag  Mac/payload/FlexSwitcher.plugin  into it. Delete any older
   FlexSwitcher.plugin / FlexSwitcher.bundle there first — two copies means
   every Flex command shows up twice.

   The plug-in is signed and notarised by Apple (Developer ID CTJRWNN7FP), so
   there is no "unidentified developer" warning to click through.


INSTALL — Windows  (Windows 10 or 11)
----------------------------------------------------------------
1. Quit After Effects.
2. Open the  Windows  folder and double-click  "Install Flex Command Console.bat".
   Windows asks for permission once: the After Effects folder is under Program
   Files. It installs into every After Effects it finds.
3. Start After Effects.

   By hand instead: copy  Windows\payload\FlexSwitcher.aex  into
     C:\Program Files\Adobe\Adobe After Effects <year>\Support Files\Plug-ins\
   and remove any older FlexSwitcher.aex from other Adobe plug-in folders.

   If SmartScreen or your antivirus asks about the installer: it is a small script
   that only copies that one file. We do not have a paid Windows signing
   certificate yet — that, not a virus, is what the question is about.


FIRST USE
----------------------------------------------------------------
1. In After Effects:  Edit > Keyboard Shortcuts, search for
   "Flex: Command Console" and give it a key (Shift+Space and Ctrl+Space are
   popular).
2. Press it. The small label near the top right should read v2.7 — if it
   shows an older number, an older copy is still installed somewhere.
3. Type  help  for every command, or  help key  to filter. Type a command's name
   without its numbers ( stagger ) and it shows you how it is written.

   Enter runs · Tab completes · Up/Down move · Esc closes
   Alt/Option-click a result to give it its own shortcut.

Commands such as "save comp" and "open flow" talk to the Flex GUI Pro panel and
need it installed and open. Everything else works on its own.


NOTHING OF YOURS IS TOUCHED
----------------------------------------------------------------
Recent commands, macros and shortcuts from earlier versions carry over — same
files, same format. To remove the console, use the Uninstall script in the same
folder; it leaves those files alone.

Questions:  support@captureflex.in  ·  https://www.captureflex.in
