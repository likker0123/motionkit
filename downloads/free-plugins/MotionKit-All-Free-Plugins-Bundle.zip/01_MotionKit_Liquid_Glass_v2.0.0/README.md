# Flex Liquid Glass 2.0

Original native C++ effect for Adobe After Effects (macOS universal, Windows x64).
Apply it to a composition-sized adjustment layer above artwork or footage, or let
Flex GUI Pro's **Convert to Liquid Glass** build the layer for you.

Match name `com.captureflex.liquidglass`, category Stylize.

## What 2.0 does

**Optics**
- Physically-based refraction: the silhouette gets a bevel height profile
  (Convex Lens, Smooth Dome, Chamfer, Concave, Flat), a 3D surface normal is
  built from it, and the view ray is bent with Snell's law using the Index of
  Refraction. Glass Depth sets how far the ray travels before it hits the
  backdrop, so it controls how much the content is pulled and magnified.
- Spectral Split is real dispersion: red, green and blue each refract with their
  own index, so fringes appear where the surface is steep and vanish where it is flat.
- Magnification zooms the content inside the glass toward the shape centre.
- Interior Blur and Frost use a true separable Gaussian pre-pass (no ghosting
  at large radii). Edge Blur adds extra softness that fades from the rim inward.

**Silhouettes**
- Built-in superellipse rounded rectangle, Source Alpha, or any Track Layer
  (shape, star, logo, text, precomp). Every silhouette becomes an exact
  Euclidean signed distance field, so custom shapes get the same full bevel
  refraction as the built-in rectangle instead of a thin rim band.
- Blob Merge: Shape B and Shape C (position, size, corner radius) melt into the
  main shape with Merge Smoothness. Mode **Merge Shapes + Silhouette** also melts
  the built-in shapes into the Track Layer / source alpha.
- Invert Silhouette (glass everywhere except the shape), Expand / Contract in
  pixels, and Track Layer Fit (Center or Stretch to Fit) for layers whose size
  differs from the comp.
- Liquid Motion: Wobble Amount / Scale / Speed / Seed animate the edge with
  smooth 3D noise; the bevel and refraction follow the moving edge.

**Light**
- Fresnel rim (thin white line + broad caustic), directional Glare with a proper
  specular term from the 3D normal, Sheen (soft top-lit gradient), Inner Shadow
  on the side facing away from the light, Rim Color, Tint.
- Glare Direction follows the After Effects angle dial: 0 degrees is up,
  positive is clockwise. The highlight lands on the edge that faces the dial.
- Reflection Layer: an environment layer reflected off the glass, weighted by
  Fresnel so it lives mostly in the bevel. Reflection Amount / Scale.
- Soft drop shadow from the (offset) silhouette with Shadow Color.

**Pipeline**
- SmartFX effect: 8, 16 and 32 bpc, region-of-interest aware, and flagged for
  Multi-Frame Rendering. Legacy PF_Cmd_RENDER fallback for hosts without SmartFX.
- Multithreaded CPU renderer (distance transform, blur and shading all parallel).

**Diagnostics**
- View: Final Result, Glass Only (alpha = silhouette), Silhouette, Height Map,
  Normals.

## Parameters

| Group | Controls |
| --- | --- |
| Silhouette | Silhouette From, Center X/Y, Shape Width/Height, Corner Radius, Superellipse Factor, Edge Feather, Invert Silhouette, Expand / Contract |
| Tracking | Track Layer, Track Layer Fit |
| Blob Merge | Shape B (on, Position, Width, Height, Corner Radius), Shape C (same), Merge Smoothness |
| Glass Optics | Refraction, Refraction Thickness (bevel width), Index of Refraction, Spectral Split, Interior Blur, Frost, Bevel Profile, Glass Depth, Magnification, Edge Blur |
| Visual Effects | Fresnel, Edge Width, Glare, Glare Direction, Rim Color, Sheen, Sheen Size, Tint, Tint Amount, Inner Shadow, Shadow, Shadow Softness, Shadow X/Y, Shadow Color |
| Reflections | Reflection Layer, Reflection Amount, Reflection Scale |
| Liquid Motion | Wobble Amount, Wobble Scale, Wobble Speed, Wobble Seed |
| Output | Quality (Fast / Balanced / High = 1 / 2 / 3 blur passes), View, Mix |

Silhouette From:
1. **Built-in Rounded Rectangle** (plus Shape B/C when enabled). An assigned
   Track Layer overrides it, as in 1.x.
2. **Source Alpha**: the layer's own alpha, or the Track Layer when assigned.
3. **Merge Shapes + Silhouette**: built-in shapes melted into the alpha / Track Layer.

Recommended custom-shape starting values (what Flex GUI Pro applies): Refraction 52,
Refraction Thickness 32, IOR 1.52, Spectral Split 3.5, Interior Blur 4, Frost 1%,
Fresnel 105%, Edge Width 16, Glare 85% at -42 degrees, Tint Amount 4%, Shadow 18%,
Shadow Softness 28.

## Compatibility

- Every parameter carries a stable disk ID. 1.x parameters keep their original
  IDs, new ones start at 100, so projects saved with 1.x reconcile their values
  when opened with 2.0 even though the parameter order changed.
- All 1.x parameter names are unchanged; Flex GUI Pro's converter (which sets
  Silhouette From, Track Layer, View, Mix and the custom-shape look by name)
  keeps working without changes.
- Refraction now accepts negative values (pushes content outward).

## Build

```bash
./build_mac.sh          # dist/macOS/FlexLiquidGlass.plugin (arm64 + x86_64, ad-hoc signed)
./build_win.sh          # dist/Windows/FlexLiquidGlass.aex (zig cross-compile)
./tests/build_harness.sh   # headless renders + numeric checks -> tests/out/*.png
```

`FlexLiquidGlassVersion.h` is the single source for the version number and the
global out-flags; the macOS PiPL (.r) includes it and `make_win_pipl.py` parses it.
The .cpp static_asserts that GlobalSetup writes the same flags. If the flags in
the PiPL and GlobalSetup ever differ, AE refuses to load the effect.

After Effects on macOS loads the copy in the system MediaCore folder, which
needs an administrator password:

```bash
sudo rm -rf "/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/FlexLiquidGlass.plugin" && sudo cp -R dist/macOS/FlexLiquidGlass.plugin "/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/"
```

## Testing without After Effects

`tests/harness.cpp` includes the plugin source, stubs the host callbacks, and
renders synthetic scenarios through both the legacy path and a simulated SmartFX
host (pre-render + render with region-of-interest requests, trimmed input and
track worlds, 32 bpc). It also checks identity (all optics off reproduces the
backdrop exactly), 8 vs 16 vs 32 bpc parity, half-resolution rendering and an
empty Track Layer. The harness must be compiled as Objective-C++ because the SDK
headers pull in Cocoa; the build script does this.

## Renderer notes

1. Worlds are converted to float RGBA.
2. The silhouette SDF is built: analytic superellipse SDFs for built-in shapes,
   a Felzenszwalb-Huttenlocher exact distance transform for alpha, polynomial
   smooth-min for Blob Merge, then expand, wobble and invert. Alpha-derived SDFs
   get a 1 px smoothing pass because a discrete distance transform leaves a
   pixel-centre sawtooth along diagonal edges that would show up as jagged
   normals.
3. The backdrop is pre-blurred (fractional-radius box passes approximating a Gaussian).
4. Per pixel: Scharr gradient of the SDF, bevel height and slope, 3D normal,
   per-channel Snell refraction, backdrop sampling, frost, tint, Fresnel rim,
   specular glare, caustic, inner shadow, sheen, environment reflection, drop
   shadow, composite.

This implementation is original. The MB Liquid Glass guide was used only as
workflow and feature-reference material; no proprietary binary or source code was copied.
