@echo off
setlocal
echo =======================================================
echo   Installing MotionKit Liquid Glass v2.0.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\MotionKitLiquidGlass.aex" (
    copy /Y "%~dp0Windows\MotionKitLiquidGlass.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitLiquidGlass.aex into %DEST%
) else if exist "%~dp0MotionKitLiquidGlass.aex" (
    copy /Y "%~dp0MotionKitLiquidGlass.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitLiquidGlass.aex into %DEST%
) else (
    echo [ERROR] MotionKitLiquidGlass.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Stylize > MotionKit Liquid Glass
echo.
pause
