@echo off
setlocal
echo =======================================================
echo   Installing MotionKit Masker v1.2 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\MotionKitMasker.aex" (
    copy /Y "%~dp0Windows\MotionKitMasker.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitMasker.aex into %DEST%
) else if exist "%~dp0MotionKitMasker.aex" (
    copy /Y "%~dp0MotionKitMasker.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitMasker.aex into %DEST%
) else (
    echo [ERROR] MotionKitMasker.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > MotionKit > MotionKit Masker
echo.
pause
