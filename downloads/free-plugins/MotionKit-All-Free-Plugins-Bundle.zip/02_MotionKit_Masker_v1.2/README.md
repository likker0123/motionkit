# Flex Masker 1.2

Flex Masker is a native C++ After Effects effect for creating non-destructive object mattes from still images without drawing a long Bézier mask by hand.

## Workflow

1. Apply **Effect > Flex > Flex Masker** to a PNG, JPG, still frame, or footage layer.
2. Keep **Selection Mode** on **Pick Object**.
3. Move **Target Point** onto the object you want to keep.
4. Increase **Color Range** until the full object is selected.
5. Increase **Edge Protection** if the selection leaks across a strong edge.
6. Use **Selection Overlay** or **Matte** while refining.
7. Return **View** to **Cutout**.

When the result is ready, use **Center Anchor to Mask** to place the layer's
anchor at the detected subject without moving the artwork. Use **I'm Done - Bake
Mask** to convert the detected boundary into a normal After Effects mask and
disable live Flex Masker processing for smoother playback. Version 1.2 bakes
all disconnected selected regions and preserves enclosed holes with separate
Add/Subtract masks instead of keeping only the largest region.

Use **Remove Background** when the background is easier to identify than the object. Put Target Point on the background. **Auto Subject** estimates the border background and keeps the enclosed foreground. **Source Alpha** refines an existing PNG alpha channel.

## Matte controls

- **Cleanup** closes small gaps and removes tiny edge defects.
- **Fill Enclosed Holes** is useful for solid products, but should stay off for objects with intentional openings such as rings or hangers.
- **Expand / Contract** grows or shrinks the matte.
- **Edge Feather** softens the final edge.
- **Matte Contrast** makes a soft matte harder or softer.

## Performance and scope

The effect runs locally and does not upload frames. Version 1.0 uses deterministic color-connected segmentation and native matte morphology, so it is fast and works best when the target has a distinguishable color or luminance boundary. Highly ambiguous objects, hair, transparent glass, or foreground/background regions with identical texture will require a later ML model backend or a small manual correction mask.

## Builds

- macOS universal: `dist/macOS/FlexMasker.plugin`
- Windows x64: `dist/Windows/FlexMasker.aex`
