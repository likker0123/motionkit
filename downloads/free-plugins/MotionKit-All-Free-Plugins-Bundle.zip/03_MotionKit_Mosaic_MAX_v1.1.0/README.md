# Flex Mosaic MAX 1.1.0

Mosaic / blur for After Effects that knows which layers to leave alone.

Put it on an **adjustment layer**, set **How Many**, pick that many layers, and
give each one a mode:

| Mode | What it does |
|---|---|
| **Exclude** | That layer stays sharp. Everything else gets the effect. |
| **Include** | The effect appears *only* where that layer is. |

Mix them freely: *Include* a tracked solid over a face, *Exclude* the title
that crosses it. With no Include slots the effect covers the whole frame.

Effect menu: **Stylize > Flex Mosaic MAX** (match name `com.captureflex.mosaicmax`).

## Parenting, transforms, 3D

A picked layer is placed using its full layer-to-world transform, so it follows
its own position / scale / rotation / anchor **and its whole parent chain**.
Parent a small solid to a tracked null, set it to Include, and the mosaic rides
the track. 3D layers are projected through the comp's active camera (or AE's
default 50 mm view when there is no camera).

A picked layer only counts while it is really there: it is ignored outside its
in/out points, and its **Opacity** scales how strongly it protects, so a title
that fades in never cuts a sharp hole before it appears. The eyeball is ignored
on purpose: hide the solid you are using as a region, like a track matte.

Next to each layer picker AE shows its own **Source / Masks / Effects & Masks**
menu. Choose *Effects & Masks* if the layer's shape comes from masks or a key.

## Controls

**Style** Mosaic, Blur, or Mosaic + Blur (soft cells).

**Cell Shape / Size / Stretch / Angle** Square, Hexagon, Triangle, Brick.
**Grid Origin** pins the pattern; **Lock Grid To** lays the cells out in a picked
layer's own space instead, so they move, scale, turn and tilt with the subject
instead of crawling across it. **Cell Gap / Gap Color** draws grout lines for a
tile or LED-wall look.

**Layers > How Many** (None to 12) reveals that many slots. Each slot:
**Layer N**, **Layer N Mode** (Exclude / Include), **Layer N Shape**:

- *Alpha* - the layer's own shape
- *Luma* - its brightness (use a black and white matte layer)
- *Bounding Box* / *Bounding Ellipse* - the layer's frame; the ellipse is the
  quick way to censor a face with a parented solid

Slots past How Many are hidden and never render, even if a layer is still set.

**Matte** *Expand* grows (+) or shrinks (-) every picked layer's footprint by
exact pixels; *Feather* softens it. *Snap To Cells* makes the boundary follow
whole cells (*Snap Threshold* = how covered a cell must be). *Clean Edges* keeps
the protected layer's colour out of the cells and the blur around it, so there
is no coloured halo; turn it off to compare.

**Mix**, and **View**: Final, Matte (white = effect), Effect Only (transparent
elsewhere, for compositing).

8, 16 and 32 bpc. Sizes are in full-resolution pixels, so Half / Quarter
previews match the final render. 8 bpc output is dithered so wide blurs do not
band; pixels the effect does not touch stay bit-identical.

## Install

macOS: copy `macOS/FlexMosaicMAX.plugin` to
`/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/`

Windows: copy `Windows/FlexMosaicMAX.aex` to
`C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\`

Restart After Effects.

## Known limits

- An effect can only see the composite beneath an adjustment layer, so
  "excluding" a layer means leaving its *footprint* untouched. Anything that
  overlaps the layer inside that footprint is left sharp too.
- Collapsed precomps / continuously rasterized layers are seen without the
  collapse. Pixel aspect ratios other than square are not compensated.
- After Effects only. (No AEGP in Premiere Pro, so no layer transforms there.)

## Building

```
./tests/build_harness.sh   # 51 checks + reference renders in tests/out
./build_mac.sh             # dist/macOS  (universal, Developer ID signed if the cert is present)
./build_mac.sh deploy      # + sudo copy into MediaCore
./build_win.sh             # dist/Windows (Zig cross-compile)
```

Source layout: `FlexMosaicCore.h` is the whole renderer and has no AE
dependency; `FlexMosaic.cpp` is the host glue (parameters, show/hide, layer
transforms, SmartFX). Version and PiPL flags live only in
`FlexMosaicVersion.h`. Parameters are identified by disk ID (`FMM_ID_*`), each
slot owning a block of ten: append, never renumber.
