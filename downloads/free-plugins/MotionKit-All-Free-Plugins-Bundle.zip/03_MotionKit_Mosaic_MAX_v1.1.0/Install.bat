@echo off
setlocal
echo =======================================================
echo   Installing MotionKit Mosaic MAX v1.1.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\MotionKitMosaicMAX.aex" (
    copy /Y "%~dp0Windows\MotionKitMosaicMAX.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitMosaicMAX.aex into %DEST%
) else if exist "%~dp0MotionKitMosaicMAX.aex" (
    copy /Y "%~dp0MotionKitMosaicMAX.aex" "%DEST%\" >nul
    echo [OK] Installed MotionKitMosaicMAX.aex into %DEST%
) else (
    echo [ERROR] MotionKitMosaicMAX.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Stylize > MotionKit Mosaic MAX
echo.
pause
