@echo off
setlocal EnableDelayedExpansion
title CaptureFlex Free Plugins Master Installer
color 0A

echo ===============================================================================
echo                CAPTUREFLEX FREE PLUGINS MASTER INSTALLER
echo                       All 9 Free Plugins Suite
echo ===============================================================================
echo.

:: 1. Check for Admin rights
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Administrator privileges required to install to Program Files.
    echo Requesting elevation...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~dpnx0\"\"' -Verb RunAs"
    exit /b
)

echo [1/5] Setting up MediaCore plug-in directory...
set "MEDIACORE=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%MEDIACORE%" (
    mkdir "%MEDIACORE%"
    echo   Created %MEDIACORE%
) else (
    echo   Found %MEDIACORE%
)

echo.
echo [2/5] Installing Native After Effects Plug-ins (.aex)...

:: 1. Flex Liquid Glass
if exist "%~dp001_Flex_Liquid_Glass_v2.0.0\Windows\FlexLiquidGlass.aex" (
    copy /Y "%~dp001_Flex_Liquid_Glass_v2.0.0\Windows\FlexLiquidGlass.aex" "%MEDIACORE%\" >nul
    echo   [OK] Flex Liquid Glass v2.0.0 (Effect ^> Stylize ^> Flex Liquid Glass)
)

:: 2. Flex Masker
if exist "%~dp002_Flex_Masker_v1.2\Windows\FlexMasker.aex" (
    copy /Y "%~dp002_Flex_Masker_v1.2\Windows\FlexMasker.aex" "%MEDIACORE%\" >nul
    echo   [OK] Flex Masker v1.2 (Effect ^> Flex ^> Flex Masker)
)

:: 3. Flex Mosaic MAX
if exist "%~dp003_Flex_Mosaic_MAX_v1.1.0\Windows\FlexMosaicMAX.aex" (
    copy /Y "%~dp003_Flex_Mosaic_MAX_v1.1.0\Windows\FlexMosaicMAX.aex" "%MEDIACORE%\" >nul
    echo   [OK] Flex Mosaic MAX v1.1.0 (Effect ^> Stylize ^> Flex Mosaic MAX)
)

:: 4. Flex Grid
if exist "%~dp004_Flex_Grid_v1.3.0\Windows-FlexGrid.aex" (
    copy /Y "%~dp004_Flex_Grid_v1.3.0\Windows-FlexGrid.aex" "%MEDIACORE%\FlexGrid.aex" >nul
    echo   [OK] Flex Grid v1.3.0 (Effect ^> Flex ^> Flex Grid)
)

:: 5. Flex Glow
if exist "%~dp005_Flex_Glow_v1.2.0\FlexGlow.aex" (
    copy /Y "%~dp005_Flex_Glow_v1.2.0\FlexGlow.aex" "%MEDIACORE%\" >nul
    echo   [OK] Flex Glow v1.2.0 (Effect ^> Stylize ^> Flex Glow)
)

:: 6. Flex Command Console Hook
if exist "%~dp006_Flex_Command_Console_v2.7\Windows\payload\FlexSwitcher.aex" (
    copy /Y "%~dp006_Flex_Command_Console_v2.7\Windows\payload\FlexSwitcher.aex" "%MEDIACORE%\" >nul
    echo   [OK] Flex Command Console v2.7 native hook (FlexSwitcher.aex)
)

:: 7. FlexBrowser Plugin & DLL
if exist "%~dp007_FlexBrowser_v2.0.0\FlexBrowser.aex" (
    copy /Y "%~dp007_FlexBrowser_v2.0.0\FlexBrowser.aex" "%MEDIACORE%\" >nul
    copy /Y "%~dp007_FlexBrowser_v2.0.0\WebView2Loader.dll" "%MEDIACORE%\" >nul
    echo   [OK] FlexBrowser v2.0.0 (Window ^> FlexBrowser)
)

echo.
echo [3/5] Setting up FlexBrowser Standalone Desktop App...
set "APPDIR=C:\Program Files\FlexBrowser"
if not exist "%APPDIR%" mkdir "%APPDIR%"
if exist "%~dp007_FlexBrowser_v2.0.0\FlexBrowser.exe" (
    copy /Y "%~dp007_FlexBrowser_v2.0.0\FlexBrowser.exe" "%APPDIR%\" >nul
    copy /Y "%~dp007_FlexBrowser_v2.0.0\WebView2Loader.dll" "%APPDIR%\" >nul
    echo   [OK] FlexBrowser App installed in %APPDIR%
)

echo.
echo [4/5] Enabling Adobe CEP PlayerDebugMode...
for /L %%i in (7,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v "PlayerDebugMode" /t REG_SZ /d "1" /f >nul 2>&1
)
echo   [OK] Enabled CSXS 7 through 16 Developer Debug Mode.

echo.
echo [5/5] Checking After Effects Plug-ins subfolders...
powershell -Command "& {
    $roots = @($env:ProgramFiles, 'C:\Adobe')
    foreach ($r in $roots) {
        if (Test-Path (Join-Path $r 'Adobe')) { $r = Join-Path $r 'Adobe' }
        if (Test-Path $r) {
            Get-ChildItem $r -Directory -Filter 'Adobe After Effects*' -ErrorAction SilentlyContinue | ForEach-Object {
                $tgt = Join-Path $_.FullName 'Support Files\Plug-ins'
                if (Test-Path $tgt) {
                    Write-Host ('  Found After Effects: ' + $_.Name) -ForegroundColor Cyan
                    if (Test-Path '%~dp006_Flex_Command_Console_v2.7\Windows\payload\FlexSwitcher.aex') {
                        Copy-Item '%~dp006_Flex_Command_Console_v2.7\Windows\payload\FlexSwitcher.aex' (Join-Path $tgt 'FlexSwitcher.aex') -Force
                    }
                }
            }
        }
    }
}"

echo.
echo ===============================================================================
echo                ALL 9 FREE PLUGINS INSTALLED SUCCESSFULLY!
echo ===============================================================================
echo.
echo Where to find them inside Adobe After Effects:
echo   1. Flex Liquid Glass   : Effect ^> Stylize ^> Flex Liquid Glass
echo   2. Flex Masker         : Effect ^> Flex ^> Flex Masker
echo   3. Flex Mosaic MAX     : Effect ^> Stylize ^> Flex Mosaic MAX
echo   4. Flex Grid           : Effect ^> Flex ^> Flex Grid
echo   5. Flex Glow           : Effect ^> Stylize ^> Flex Glow  (or Window ^> Extensions ^> Flex Glow)
echo   6. Flex Console        : Edit ^> Keyboard Shortcuts ^> search 'Flex: Command Console'
echo                            (or Window ^> Extensions ^> Flex Command Console)
echo   7. FlexBrowser         : Window ^> FlexBrowser
echo   8. Flex Web To AE      : Browser Extension (Load Unpacked in Chrome/Edge)
echo   9. Flex Downloader     : Window ^> Extensions ^> Flex Downloader
echo.
echo Press any key to open the visual guide...
pause >nul
start "" "%~dp0README_FREE_PLUGINS_GUIDE.html"
