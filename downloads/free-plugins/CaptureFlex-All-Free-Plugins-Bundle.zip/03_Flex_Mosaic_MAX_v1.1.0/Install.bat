@echo off
setlocal
echo =======================================================
echo   Installing Flex Mosaic MAX v1.1.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\FlexMosaicMAX.aex" (
    copy /Y "%~dp0Windows\FlexMosaicMAX.aex" "%DEST%\" >nul
    echo [OK] Installed FlexMosaicMAX.aex into %DEST%
) else if exist "%~dp0FlexMosaicMAX.aex" (
    copy /Y "%~dp0FlexMosaicMAX.aex" "%DEST%\" >nul
    echo [OK] Installed FlexMosaicMAX.aex into %DEST%
) else (
    echo [ERROR] FlexMosaicMAX.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Stylize > Flex Mosaic MAX
echo.
pause
