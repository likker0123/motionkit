@echo off
setlocal
echo =======================================================
echo   Installing Flex Liquid Glass v2.0.0 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\FlexLiquidGlass.aex" (
    copy /Y "%~dp0Windows\FlexLiquidGlass.aex" "%DEST%\" >nul
    echo [OK] Installed FlexLiquidGlass.aex into %DEST%
) else if exist "%~dp0FlexLiquidGlass.aex" (
    copy /Y "%~dp0FlexLiquidGlass.aex" "%DEST%\" >nul
    echo [OK] Installed FlexLiquidGlass.aex into %DEST%
) else (
    echo [ERROR] FlexLiquidGlass.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Stylize > Flex Liquid Glass
echo.
pause
