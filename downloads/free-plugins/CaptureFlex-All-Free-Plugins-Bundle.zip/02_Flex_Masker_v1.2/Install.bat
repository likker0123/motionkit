@echo off
setlocal
echo =======================================================
echo   Installing Flex Masker v1.2 for Windows
echo =======================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~dpnx0\"' -Verb RunAs"
    exit /b
)
set "DEST=C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%~dp0Windows\FlexMasker.aex" (
    copy /Y "%~dp0Windows\FlexMasker.aex" "%DEST%\" >nul
    echo [OK] Installed FlexMasker.aex into %DEST%
) else if exist "%~dp0FlexMasker.aex" (
    copy /Y "%~dp0FlexMasker.aex" "%DEST%\" >nul
    echo [OK] Installed FlexMasker.aex into %DEST%
) else (
    echo [ERROR] FlexMasker.aex not found!
)
echo.
echo Restart After Effects. Effect is located at:
echo   Effect > Flex > Flex Masker
echo.
pause
