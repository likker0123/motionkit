@echo off
setlocal
title Install MotionKit Ultimate for Premiere Pro
color 0A

echo =======================================================
echo     MOTIONKIT ULTIMATE FOR PREMIERE PRO INSTALLER
echo =======================================================
echo.
echo Installing MotionKit Ultimate for PR into Adobe CEP Extensions...

set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionkit.ultimate.pr"
if not exist "%APPDATA%\Adobe\CEP\extensions" (
    mkdir "%APPDATA%\Adobe\CEP\extensions"
)

xcopy /E /I /Y /Q "%~dp0com.motionkit.ultimate.pr" "%TARGET_DIR%" >nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to copy extension files.
    pause
    exit /b 1
)

echo [OK] Files copied to: %TARGET_DIR%

echo Setting up Adobe PlayerDebugMode for Premiere Pro...
for /L %%i in (7,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v "PlayerDebugMode" /t REG_SZ /d "1" /f >nul 2>&1
)
echo [OK] Adobe CEP Debug Mode enabled!

echo.
echo =======================================================
echo          INSTALLATION COMPLETE SUCCESSFULLY!
echo =======================================================
echo.
echo Open Adobe Premiere Pro and navigate to:
echo   Window ^> Extensions ^> MotionKit Ultimate for PR
echo.
echo To Activate:
echo   Use your Machine ID with MotionKit-License-Keygen.html
echo   Or use Master Key: MOTIONKIT-MASTER-LIFETIME-ACCESS
echo.
pause
