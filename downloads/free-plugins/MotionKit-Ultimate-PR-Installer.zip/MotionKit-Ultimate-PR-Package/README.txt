===============================================================
       MOTIONKIT ULTIMATE FOR ADOBE PREMIERE PRO (PR)
===============================================================

MotionKit Ultimate for PR is the all-in-one Premiere Pro extension
featuring:
 - Silence Remover / Auto Cut
 - AutoCaptions & Subtitle Editor
 - AI Background Remover
 - Camera 3D
 - Shake Logic & Presets
 - Speed Ramp & Graph Editor (Greedy-Fit Baking)
 - Retake Detection & Shared Notes
 - 20+ Sequences & Adjustment Presets
 - Downloader & Browser Integration

---------------------------------------------------------------
1-CLICK INSTALLATION:
---------------------------------------------------------------
1. Close Adobe Premiere Pro if it is running.
2. Double-click "Install.bat".
3. Wait for the green success message.
4. Launch Adobe Premiere Pro.
5. In Premiere Pro, go to top menu:
   Window > Extensions > MotionKit Ultimate for PR

---------------------------------------------------------------
LICENSE ACTIVATION:
---------------------------------------------------------------
Option 1 (Instant Master Key):
  Enter: MOTIONKIT-MASTER-LIFETIME-ACCESS
  Click "UNLOCK MOTIONKIT" - unlocked instantly!

Option 2 (Machine Locked Key):
  1. Note your Machine ID shown on the MotionKit lock screen.
  2. Open "MotionKit-License-Keygen.html" on your Desktop.
  3. Paste your Machine ID and click "Generate Key".
  4. Paste the generated key into MotionKit and click "UNLOCK MOTIONKIT".

---------------------------------------------------------------
COMPATIBILITY:
---------------------------------------------------------------
 - Adobe Premiere Pro 2020 through 2026+ (v14.0 - v99.9)
 - Windows 10 / Windows 11
===============================================================
