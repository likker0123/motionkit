@echo off
setlocal
title Uninstall MotionKit Ultimate for Premiere Pro
color 0C

echo =======================================================
echo    UNINSTALL MOTIONKIT ULTIMATE FOR PREMIERE PRO
echo =======================================================
echo.
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionkit.ultimate.pr"

if exist "%TARGET_DIR%" (
    echo Removing %TARGET_DIR%...
    rmdir /S /Q "%TARGET_DIR%"
    echo [OK] Uninstalled successfully!
) else (
    echo [INFO] Extension not found in Adobe CEP folder.
)

echo.
pause
