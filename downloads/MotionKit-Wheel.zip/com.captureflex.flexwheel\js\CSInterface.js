﻿/**
 * CSInterface - Complete Adobe CEP Bridge
 */

var SystemPath = {
    USER_DATA: "userData",
    COMMON_FILES: "commonFiles",
    MY_DOCUMENTS: "myDocuments",
    APPLICATION: "application",
    EXTENSION: "extension",
    HOST_APPLICATION: "hostApplication"
};

function CSInterface() {}

CSInterface.prototype.evalScript = function(script, callback) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.evalScript(script, callback || function() {});
    } else {
        console.log("[MOCK evalScript]:", script);
        if (callback) callback("OK");
    }
};

CSInterface.prototype.getSystemPath = function(pathType) {
    if (window.__adobe_cep__) {
        var path = window.__adobe_cep__.getSystemPath(pathType);
        var OSVersion = this.getOSInformation();
        if (OSVersion.indexOf("Windows") >= 0) {
            path = path.replace("file:///", "");
            path = path.replace(/\//g, "\\");
            return decodeURI(path);
        }
        return path;
    }
    return "";
};

CSInterface.prototype.getOSInformation = function() {
    if (window.__adobe_cep__) {
        return window.__adobe_cep__.getOSInformation();
    }
    return navigator.userAgent;
};

CSInterface.prototype.getHostEnvironment = function() {
    if (window.__adobe_cep__) {
        return JSON.parse(window.__adobe_cep__.getHostEnvironment());
    }
    return { appName: "AEFT", appVersion: "24.0" };
};

window.CSInterface = CSInterface;
window.SystemPath = SystemPath;
