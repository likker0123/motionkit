@echo off
title Flex Wheel - 1-Click Installer
color 0A

echo ========================================================
echo       FLEX WHEEL - ADOBE EXTENSION AUTO INSTALLER
echo ========================================================
echo.
echo [1/3] Enabling Adobe Extension Debug Mode in Registry...
reg add "HKCU\Software\Adobe\CSXS.7" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo Done!

echo.
echo [2/3] Setting up Adobe Extensions Directory...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
echo Done!

echo.
echo [3/3] Copying Flex Wheel to Extensions Directory...
xcopy /E /I /Y "%~dp0com.captureflex.flexwheel" "%APPDATA%\Adobe\CEP\extensions\com.captureflex.flexwheel" >nul
echo Done!

echo.
echo ========================================================
echo        FLEX WHEEL SUCCESSFULLY INSTALLED!
echo ========================================================
echo.
echo Ab Adobe After Effects ya Premiere Pro kholein:
echo Top Menu: Window -^> Extensions -^> Flex Wheel
echo.
pause
