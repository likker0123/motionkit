﻿/**
 * Flex Wheel - Host ExtendScript Engine
 * Runs inside Adobe After Effects & Premiere Pro
 */

// Helper to get active AE composition
function fw_getComp() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return null;
    }
    return comp;
}

// 1. 3x3 ANCHOR POINT SNAPPING
function fw_anchor(pos) {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";

    app.beginUndoGroup("Flex Wheel: Anchor " + pos);

    for (var i = 0; i < sel.length; i++) {
        var layer = sel[i];
        var rect;
        try {
            rect = layer.sourceRectAtTime(comp.time, false);
        } catch (e) {
            rect = { top: 0, left: 0, width: layer.width || 100, height: layer.height || 100 };
        }

        var tX = rect.left + rect.width / 2;
        var tY = rect.top + rect.height / 2;

        if (pos.charAt(1) === 'L' || pos === 'TL' || pos === 'ML' || pos === 'BL') tX = rect.left;
        else if (pos.charAt(1) === 'R' || pos === 'TR' || pos === 'MR' || pos === 'BR') tX = rect.left + rect.width;

        if (pos.charAt(0) === 'T') tY = rect.top;
        else if (pos.charAt(0) === 'B') tY = rect.top + rect.height;

        var curAnchor = layer.anchorPoint.value;
        var dX = tX - curAnchor[0];
        var dY = tY - curAnchor[1];

        var scale = layer.scale.value;
        var sX = scale[0] / 100;
        var sY = scale[1] / 100;
        var rad = layer.rotation.value * Math.PI / 180;

        var mX = (dX * sX * Math.cos(rad)) - (dY * sY * Math.sin(rad));
        var mY = (dX * sX * Math.sin(rad)) + (dY * sY * Math.cos(rad));

        if (curAnchor.length === 3) layer.anchorPoint.setValue([tX, tY, curAnchor[2]]);
        else layer.anchorPoint.setValue([tX, tY]);

        var curPos = layer.position.value;
        if (layer.position.isTimeVarying) {
            for (var k = 1; k <= layer.position.numKeys; k++) {
                var kv = layer.position.keyValue(k);
                layer.position.setValueAtKey(k, kv.length === 3 ? [kv[0] + mX, kv[1] + mY, kv[2]] : [kv[0] + mX, kv[1] + mY]);
            }
        } else {
            layer.position.setValue(curPos.length === 3 ? [curPos[0] + mX, curPos[1] + mY, curPos[2]] : [curPos[0] + mX, curPos[1] + mY]);
        }
    }

    app.endUndoGroup();
    return "OK";
}

// 2. CREATE NULL & PARENT
function fw_nullAndParent() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";

    app.beginUndoGroup("Flex Wheel: Null & Parent");
    var sel = comp.selectedLayers;
    var nullLayer = comp.layers.addNull();
    nullLayer.name = "Controller Null";

    if (sel.length > 0) {
        var minIn = comp.duration, maxOut = 0, aX = 0, aY = 0;
        for (var i = 0; i < sel.length; i++) {
            var l = sel[i];
            if (l.inPoint < minIn) minIn = l.inPoint;
            if (l.outPoint > maxOut) maxOut = l.outPoint;
            aX += l.position.value[0];
            aY += l.position.value[1];
        }
        nullLayer.position.setValue([aX / sel.length, aY / sel.length]);
        nullLayer.inPoint = minIn;
        nullLayer.outPoint = maxOut;

        for (var j = 0; j < sel.length; j++) {
            sel[j].parent = nullLayer;
        }
    } else {
        nullLayer.position.setValue([comp.width / 2, comp.height / 2]);
    }

    app.endUndoGroup();
    return "OK";
}

// 3. CREATE ADJUSTMENT LAYER
function fw_createAdjustment() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";

    app.beginUndoGroup("Flex Wheel: Adjustment Layer");
    var adj = comp.layers.addSolid([1, 1, 1], "Adjustment Layer", comp.width, comp.height, comp.pixelAspect, comp.duration);
    adj.adjustmentLayer = true;

    var sel = comp.selectedLayers;
    if (sel.length > 0) {
        var minIn = comp.duration, maxOut = 0;
        for (var i = 0; i < sel.length; i++) {
            if (sel[i].inPoint < minIn) minIn = sel[i].inPoint;
            if (sel[i].outPoint > maxOut) maxOut = sel[i].outPoint;
        }
        adj.inPoint = minIn;
        adj.outPoint = maxOut;
    } else {
        adj.inPoint = comp.workAreaStart;
        adj.outPoint = comp.workAreaStart + comp.workAreaDuration;
    }

    app.endUndoGroup();
    return "OK";
}

// 4. CREATE SOLID
function fw_createSolid() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    app.beginUndoGroup("Flex Wheel: Create Solid");
    comp.layers.addSolid([0.1, 0.12, 0.15], "Solid Layer", comp.width, comp.height, comp.pixelAspect, comp.duration);
    app.endUndoGroup();
    return "OK";
}

// 5. CREATE CAMERA RIG
function fw_createCamera() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    app.beginUndoGroup("Flex Wheel: Camera Rig");
    var camNull = comp.layers.addNull();
    camNull.name = "Camera Control Null";
    camNull.threeDLayer = true;
    camNull.position.setValue([comp.width / 2, comp.height / 2, 0]);

    var cam = comp.layers.addCamera("35mm Camera", [comp.width / 2, comp.height / 2]);
    cam.parent = camNull;
    app.endUndoGroup();
    return "OK";
}

// 6. TIMELINE SPLIT AT CTI
function fw_split() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";

    app.beginUndoGroup("Flex Wheel: Split Layer");
    var t = comp.time;
    for (var i = 0; i < sel.length; i++) {
        var l = sel[i];
        if (t > l.inPoint && t < l.outPoint) {
            var dup = l.duplicate();
            l.outPoint = t;
            dup.inPoint = t;
        }
    }
    app.endUndoGroup();
    return "OK";
}

// 7. PRE-COMPOSE TRIMMED
function fw_precomp() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";

    app.beginUndoGroup("Flex Wheel: Pre-comp");
    var indices = [];
    var minIn = comp.duration, maxOut = 0;
    for (var i = 0; i < sel.length; i++) {
        indices.push(sel[i].index);
        if (sel[i].inPoint < minIn) minIn = sel[i].inPoint;
        if (sel[i].outPoint > maxOut) maxOut = sel[i].outPoint;
    }

    var newComp = comp.layers.precompose(indices, "Flex Pre-comp", true);
    var precompLayer = comp.selectedLayers[0];
    if (precompLayer) {
        precompLayer.inPoint = minIn;
        precompLayer.outPoint = maxOut;
    }
    app.endUndoGroup();
    return "OK";
}

// 8. TRIM IN / TRIM OUT
function fw_trimIn() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";
    app.beginUndoGroup("Flex Wheel: Trim In");
    for (var i = 0; i < sel.length; i++) sel[i].inPoint = comp.time;
    app.endUndoGroup();
    return "OK";
}

function fw_trimOut() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";
    app.beginUndoGroup("Flex Wheel: Trim Out");
    for (var i = 0; i < sel.length; i++) sel[i].outPoint = comp.time;
    app.endUndoGroup();
    return "OK";
}

// 9. SMOOTH EASE
function fw_smoothEase() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    app.beginUndoGroup("Flex Wheel: Smooth Ease 70%");
    var props = comp.selectedProperties;
    if (!props || props.length === 0) return "NO_PROPS";

    var easeOut = new KeyframeEase(0, 70);
    var easeIn = new KeyframeEase(0, 70);

    for (var p = 0; p < props.length; p++) {
        var prop = props[p];
        if (prop.canVaryOverTime && prop.numKeys > 0) {
            for (var k = 0; k < prop.selectedKeys.length; k++) {
                var ki = prop.selectedKeys[k];
                prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.BEZIER);
                prop.setTemporalEaseAtKey(ki, [easeIn], [easeOut]);
            }
        }
    }
    app.endUndoGroup();
    return "OK";
}

// 10. EXPRESSIONS
function fw_expression(expr) {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    app.beginUndoGroup("Flex Wheel: Expression");
    var props = comp.selectedProperties;
    if (!props || props.length === 0) return "NO_PROPS";

    for (var p = 0; p < props.length; p++) {
        try {
            props[p].expression = expr;
        } catch (e) {}
    }
    app.endUndoGroup();
    return "OK";
}

// 11. ADD EFFECTS (e.g. Gaussian Blur, Glow, Shadow, Tint)
function fw_addEffect(effectName) {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;

    app.beginUndoGroup("Flex Wheel: Add " + effectName);

    // If no layer selected, create adjustment layer automatically (like Page 4 of PDF)
    if (sel.length === 0) {
        var adj = comp.layers.addSolid([1, 1, 1], effectName + " Layer", comp.width, comp.height, comp.pixelAspect, comp.duration);
        adj.adjustmentLayer = true;
        sel = [adj];
    }

    for (var i = 0; i < sel.length; i++) {
        try {
            sel[i].Effects.addProperty(effectName);
        } catch (e) {
            // fallback
        }
    }

    app.endUndoGroup();
    return "OK";
}

// 12. CENTER LAYER
function fw_center() {
    var comp = fw_getComp();
    if (!comp) return "NO_COMP";
    var sel = comp.selectedLayers;
    if (sel.length === 0) return "NO_LAYER";
    app.beginUndoGroup("Flex Wheel: Center Layer");
    for (var i = 0; i < sel.length; i++) {
        var p = sel[i].position.value;
        sel[i].position.setValue(p.length === 3 ? [comp.width / 2, comp.height / 2, p[2]] : [comp.width / 2, comp.height / 2]);
    }
    app.endUndoGroup();
    return "OK";
}

// 13. PURGE CACHE
function fw_purge() {
    app.purge(PurgeTarget.ALL_CACHES);
    return "OK";
}
