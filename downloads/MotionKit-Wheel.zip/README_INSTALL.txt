﻿==============================================================
  ⚡ FLEX WHEEL - KISI BHI PC MEIN INSTALL KARNE KA TAREEQA
==============================================================

Option 1: 1-Click Auto Install (Sabse Aasan)
---------------------------------------------
1. Is folder ko Pendrive / Google Drive ke zariye doosre PC par le jaayein.
2. "install.bat" file par double-click karein.
3. 2 second mein screen par "SUCCESSFULLY INSTALLED" likha aayega.
4. Adobe After Effects open karein.
5. Top menu se jaayein: Window -> Extensions -> Flex Wheel!


Option 2: Manual Install (Bina installer ke khud karna ho toh)
--------------------------------------------------------------
Agar aap khud file copy-paste karna chahte hain:

Step 1:
Windows key + R dabayein, aur likhein:
%APPDATA%\Adobe\CEP\extensions
(Agar folder na ho toh bana lein).

Step 2:
"com.captureflex.flexwheel" folder ko wahan paste kar dein.

Step 3: (One-time registry enable)
Windows key + R dabayein, likhein "regedit" aur Enter karein.
HKEY_CURRENT_USER\Software\Adobe\CSXS.10 (aur jo bhi CSXS version ho) par jaayein,
Right-click -> New -> String Value banayein:
Name: PlayerDebugMode
Value: 1

Step 4:
After Effects open karein -> Window -> Extensions -> Flex Wheel!
==============================================================
