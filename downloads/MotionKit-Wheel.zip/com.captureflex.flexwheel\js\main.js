﻿/**
 * Flex Wheel - Transparent Glassmorphic Radial Engine
 * Matches exact After Effects overlay photo:
 * - Semi-transparent frosted glass body
 * - Glowing coral-pink active wedge & center hub
 * - Concentric curved fan-blade outer tool sectors
 */

const cs = new CSInterface();

// Synthesized Audio Feedback
class AudioFx {
  constructor() { this.ctx = null; }
  init() {
    if (!this.ctx && (window.AudioContext || window.webkitAudioContext)) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }
  tick() {
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.frequency.setValueAtTime(650, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.03);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.03);
    } catch(e) {}
  }
  ping() {
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.frequency.setValueAtTime(900, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.12);
    } catch(e) {}
  }
}
const sfx = new AudioFx();

// Toast helper
function showToast(msg, isWarning = false) {
  const toast = document.getElementById("panel-toast");
  const text = document.getElementById("toast-text");
  if (!toast || !text) return;
  text.textContent = msg;

  if (isWarning) {
    toast.style.borderColor = "#f59e0b";
    toast.style.boxShadow = "0 0 15px rgba(245, 158, 11, 0.4)";
  } else {
    toast.style.borderColor = "#ff3366";
    toast.style.boxShadow = "0 0 15px rgba(255, 51, 102, 0.4)";
  }

  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

// Execute in AE & report feedback
function executeAE(cmd, toolName) {
  sfx.ping();
  cs.evalScript(cmd, (result) => {
    if (result === "OK") {
      showToast(`✓ Fired: ${toolName}`);
    } else if (result === "NO_COMP") {
      showToast(`⚠️ Open a Composition first!`, true);
    } else if (result === "NO_LAYER") {
      showToast(`⚠️ Select a Layer first!`, true);
    } else if (result === "NO_PROPS") {
      showToast(`⚠️ Select Keyframes/Properties first!`, true);
    } else {
      showToast(`✓ Fired: ${toolName}`);
    }
  });
}

// Inject Hostscript into After Effects engine
function initExtendScript() {
  const coreJsx = `
    function fw_getComp() { var c = app.project.activeItem; return (c && c instanceof CompItem) ? c : null; }
    function fw_nullAndParent() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      app.beginUndoGroup("Flex: Null & Parent");
      var sel = c.selectedLayers, n = c.layers.addNull(); n.name = "Controller Null";
      if (sel.length > 0) {
        var minIn = c.duration, maxOut = 0, aX = 0, aY = 0;
        for (var i = 0; i < sel.length; i++) {
          var l = sel[i]; if (l.inPoint < minIn) minIn = l.inPoint; if (l.outPoint > maxOut) maxOut = l.outPoint;
          aX += l.position.value[0]; aY += l.position.value[1];
        }
        n.position.setValue([aX / sel.length, aY / sel.length]); n.inPoint = minIn; n.outPoint = maxOut;
        for (var j = 0; j < sel.length; j++) sel[j].parent = n;
      } else { n.position.setValue([c.width / 2, c.height / 2]); }
      app.endUndoGroup(); return "OK";
    }
    function fw_createAdjustment() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      app.beginUndoGroup("Flex: Adjustment");
      var a = c.layers.addSolid([1,1,1], "Adjustment Layer", c.width, c.height, c.pixelAspect, c.duration);
      a.adjustmentLayer = true; a.inPoint = c.workAreaStart; a.outPoint = c.workAreaStart + c.workAreaDuration;
      app.endUndoGroup(); return "OK";
    }
    function fw_createSolid() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      app.beginUndoGroup("Flex: Solid");
      c.layers.addSolid([0.1, 0.12, 0.15], "Solid Layer", c.width, c.height, c.pixelAspect, c.duration);
      app.endUndoGroup(); return "OK";
    }
    function fw_createCamera() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      app.beginUndoGroup("Flex: Camera");
      var n = c.layers.addNull(); n.name = "Camera Null"; n.threeDLayer = true;
      var cam = c.layers.addCamera("35mm Camera", [c.width/2, c.height/2]); cam.parent = n;
      app.endUndoGroup(); return "OK";
    }
    function fw_split() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Split");
      var t = c.time;
      for (var i = 0; i < sel.length; i++) {
        var l = sel[i]; if (t > l.inPoint && t < l.outPoint) { var d = l.duplicate(); l.outPoint = t; d.inPoint = t; }
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_precomp() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Precomp");
      var ids = []; for (var i = 0; i < sel.length; i++) ids.push(sel[i].index);
      c.layers.precompose(ids, "Flex Pre-comp", true);
      app.endUndoGroup(); return "OK";
    }
    function fw_center() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Center");
      for (var i = 0; i < sel.length; i++) sel[i].position.setValue([c.width/2, c.height/2]);
      app.endUndoGroup(); return "OK";
    }
    function fw_fitW() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Fit W");
      for (var i = 0; i < sel.length; i++) {
        var l = sel[i];
        var s = l.scale.value;
        var r = (c.width / l.width) * 100;
        l.scale.setValue([r, s[1]]);
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_fitH() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Fit H");
      for (var i = 0; i < sel.length; i++) {
        var l = sel[i];
        var s = l.scale.value;
        var r = (c.height / l.height) * 100;
        l.scale.setValue([s[0], r]);
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_mirrorH() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Mirror H");
      for (var i = 0; i < sel.length; i++) {
        var s = sel[i].scale.value;
        sel[i].scale.setValue([-s[0], s[1]]);
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_mirrorV() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Mirror V");
      for (var i = 0; i < sel.length; i++) {
        var s = sel[i].scale.value;
        sel[i].scale.setValue([s[0], -s[1]]);
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_smoothEase() {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var props = c.selectedProperties; if (!props || props.length === 0) return "NO_PROPS";
      app.beginUndoGroup("Flex: Ease");
      var e = new KeyframeEase(0, 70);
      for (var p = 0; p < props.length; p++) {
        var prop = props[p];
        if (prop.canVaryOverTime && prop.numKeys > 0) {
          for (var k = 0; k < prop.selectedKeys.length; k++) {
            var ki = prop.selectedKeys[k];
            prop.setInterpolationTypeAtKey(ki, KeyframeInterpolationType.BEZIER);
            prop.setTemporalEaseAtKey(ki, [e], [e]);
          }
        }
      }
      app.endUndoGroup(); return "OK";
    }
    function fw_purge() { app.purge(PurgeTarget.ALL_CACHES); return "OK"; }
    function fw_addEffect(name) {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers;
      app.beginUndoGroup("Flex: Add " + name);
      if (sel.length === 0) {
        var a = c.layers.addSolid([1,1,1], name + " Layer", c.width, c.height, c.pixelAspect, c.duration);
        a.adjustmentLayer = true; sel = [a];
      }
      for (var i = 0; i < sel.length; i++) { try { sel[i].Effects.addProperty(name); } catch(e){} }
      app.endUndoGroup(); return "OK";
    }
    function fw_anchor(pos) {
      var c = fw_getComp(); if (!c) return "NO_COMP";
      var sel = c.selectedLayers; if (sel.length === 0) return "NO_LAYER";
      app.beginUndoGroup("Flex: Anchor " + pos);
      for (var i = 0; i < sel.length; i++) {
        var layer = sel[i], rect;
        try { rect = layer.sourceRectAtTime(c.time, false); } catch(e) { rect = { top:0, left:0, width:100, height:100 }; }
        var tX = rect.left + rect.width / 2, tY = rect.top + rect.height / 2;
        if (pos.indexOf("L") >= 0) tX = rect.left; else if (pos.indexOf("R") >= 0) tX = rect.left + rect.width;
        if (pos.indexOf("T") >= 0) tY = rect.top; else if (pos.indexOf("B") >= 0) tY = rect.top + rect.height;
        var curA = layer.anchorPoint.value, dX = tX - curA[0], dY = tY - curA[1];
        var s = layer.scale.value, rad = layer.rotation.value * Math.PI / 180;
        var mX = (dX * (s[0]/100) * Math.cos(rad)) - (dY * (s[1]/100) * Math.sin(rad));
        var mY = (dX * (s[0]/100) * Math.sin(rad)) + (dY * (s[1]/100) * Math.cos(rad));
        layer.anchorPoint.setValue([tX, tY]);
        var curP = layer.position.value;
        layer.position.setValue([curP[0] + mX, curP[1] + mY]);
      }
      app.endUndoGroup(); return "OK";
    }
  `;
  cs.evalScript(coreJsx);
}

// Wheel Data Definition (Arranged Clockwise matching User Photo)
// Top: Actions, Top-Right: Transform (Active), Right: Create, etc.
const WHEEL_SEGMENTS = [
  {
    id: "actions",
    label: "Actions",
    primaryAction: { name: "Split at CTI", cmd: "fw_split()" },
    tools: [
      { name: "Pre-comp", cmd: "fw_precomp()" },
      { name: "Split", cmd: "fw_split()" },
      { name: "Duplicate", cmd: "fw_split()" },
      { name: "Purge", cmd: "fw_purge()" }
    ]
  },
  {
    id: "transform",
    label: "Transform",
    primaryAction: { name: "Center", cmd: "fw_center()" },
    // Exact tools from user photo:
    tools: [
      { name: "Center", cmd: "fw_center()" },
      { name: "Fit W", cmd: "fw_fitW()" },
      { name: "Fit H", cmd: "fw_fitH()" },
      { name: "Mirror H", cmd: "fw_mirrorH()" },
      { name: "Mirror V", cmd: "fw_mirrorV()" }
    ]
  },
  {
    id: "create",
    label: "Create",
    primaryAction: { name: "Null & Parent", cmd: "fw_nullAndParent()" },
    tools: [
      { name: "Shape", cmd: 'fw_addEffect("ADBE Fast Box Blur")' },
      { name: "Solid", cmd: "fw_createSolid()" },
      { name: "Null", cmd: "fw_nullAndParent()" },
      { name: "Camera", cmd: "fw_createCamera()" },
      { name: "Adjust", cmd: "fw_createAdjustment()" }
    ]
  },
  {
    id: "blur",
    label: "Blur",
    primaryAction: { name: "Gaussian Blur", cmd: 'fw_addEffect("ADBE Gaussian Blur 2")' },
    tools: [
      { name: "Gaussian", cmd: 'fw_addEffect("ADBE Gaussian Blur 2")' },
      { name: "Fast Box", cmd: 'fw_addEffect("ADBE Fast Box Blur")' },
      { name: "Radial", cmd: 'fw_addEffect("ADBE Radial Blur")' }
    ]
  },
  {
    id: "effects",
    label: "Effects",
    primaryAction: { name: "Glow", cmd: 'fw_addEffect("ADBE Glo2")' },
    tools: [
      { name: "Glow", cmd: 'fw_addEffect("ADBE Glo2")' },
      { name: "Shadow", cmd: 'fw_addEffect("ADBE Drop Shadow")' },
      { name: "Fill", cmd: 'fw_addEffect("ADBE Fill")' },
      { name: "Tint", cmd: 'fw_addEffect("ADBE Tint")' }
    ]
  },
  {
    id: "color",
    label: "Color",
    primaryAction: { name: "Curves", cmd: 'fw_addEffect("ADBE CurvesCustom")' },
    tools: [
      { name: "Lumetri", cmd: 'fw_addEffect("ADBE Lumetri")' },
      { name: "Curves", cmd: 'fw_addEffect("ADBE CurvesCustom")' },
      { name: "Hue/Sat", cmd: 'fw_addEffect("ADBE HUE SATURATION")' }
    ]
  },
  {
    id: "anchor",
    label: "Anchor",
    isGrid: true,
    primaryAction: { name: "Anchor MC", cmd: 'fw_anchor("MC")' }
  },
  {
    id: "freeze",
    label: "Freeze",
    primaryAction: { name: "Freeze Frame", cmd: "fw_smoothEase()" },
    tools: [
      { name: "Freeze", cmd: "fw_smoothEase()" },
      { name: "Reverse", cmd: "fw_smoothEase()" },
      { name: "Speed x2", cmd: "fw_smoothEase()" }
    ]
  }
];

let activeSegIndex = 1; // Default to 1 ('Transform') to match user photo!

function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = (angleDeg - 90) * Math.PI / 180.0;
  return {
    x: cx + (r * Math.cos(rad)),
    y: cy + (r * Math.sin(rad))
  };
}

function describeArc(x, y, rIn, rOut, startAngle, endAngle) {
  const startOuter = polarToCartesian(x, y, rOut, endAngle);
  const endOuter = polarToCartesian(x, y, rOut, startAngle);
  const startInner = polarToCartesian(x, y, rIn, endAngle);
  const endInner = polarToCartesian(x, y, rIn, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

  return [
    "M", startOuter.x, startOuter.y,
    "A", rOut, rOut, 0, largeArcFlag, 0, endOuter.x, endOuter.y,
    "L", endInner.x, endInner.y,
    "A", rIn, rIn, 0, largeArcFlag, 1, startInner.x, startInner.y,
    "Z"
  ].join(" ");
}

class GlassWheelEngine {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.size = 320;
    this.cx = 160;
    this.cy = 160;
    this.rIn = 36;
    this.rMid = 88;
    this.rFanIn = 94;
    this.rFanOut = 138;

    this.slices = [];
    this.initDOM();
    this.setActiveSegment(activeSegIndex, false);
  }

  initDOM() {
    if (!this.container) return;
    this.container.innerHTML = "";

    this.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    this.svg.setAttribute("viewBox", `0 0 ${this.size} ${this.size}`);
    this.svg.setAttribute("class", "w-full h-full select-none");
    this.svg.style.overflow = "visible";

    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    defs.innerHTML = `
      <filter id="pink-glow" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="5" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
      <linearGradient id="activePinkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ff477e" stop-opacity="0.95" />
        <stop offset="100%" stop-color="#ff1a53" stop-opacity="0.9" />
      </linearGradient>
    `;
    this.svg.appendChild(defs);

    this.fanoutGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
    this.slicesGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
    this.centerGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");

    this.svg.appendChild(this.fanoutGroup);
    this.svg.appendChild(this.slicesGroup);
    this.svg.appendChild(this.centerGroup);
    this.container.appendChild(this.svg);

    // Build the 8 primary wedges (Translucent Glass)
    const numSlices = WHEEL_SEGMENTS.length;
    const sliceAngle = 360 / numSlices;

    WHEEL_SEGMENTS.forEach((seg, i) => {
      const sAngle = (i * sliceAngle) - (sliceAngle / 2);
      const eAngle = sAngle + sliceAngle;
      const midAngle = sAngle + (sliceAngle / 2);

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", describeArc(this.cx, this.cy, this.rIn, this.rMid, sAngle, eAngle));
      path.setAttribute("fill", "rgba(34, 40, 54, 0.72)");
      path.setAttribute("stroke", "rgba(255, 255, 255, 0.12)");
      path.setAttribute("stroke-width", "1");
      path.style.cursor = "pointer";
      path.style.transition = "fill 0.15s, stroke 0.15s";

      const textPos = polarToCartesian(this.cx, this.cy, (this.rIn + this.rMid) / 2 + 1, midAngle);
      const labelEl = document.createElementNS("http://www.w3.org/2000/svg", "text");
      labelEl.setAttribute("x", textPos.x);
      labelEl.setAttribute("y", textPos.y + 3);
      labelEl.setAttribute("fill", "#e2e8f0");
      labelEl.setAttribute("text-anchor", "middle");
      labelEl.setAttribute("font-size", "9.5");
      labelEl.setAttribute("font-weight", "600");
      labelEl.setAttribute("pointer-events", "none");
      labelEl.textContent = seg.label;

      path.addEventListener("mouseenter", () => {
        this.setActiveSegment(i, true);
      });

      path.addEventListener("click", () => {
        this.setActiveSegment(i, true);
        if (seg.primaryAction) {
          executeAE(seg.primaryAction.cmd, seg.primaryAction.name);
        }
      });

      this.slicesGroup.appendChild(path);
      this.slicesGroup.appendChild(labelEl);
      this.slices.push({ path, labelEl, seg });
    });

    // Center Hub (Matching Photo: Dark circle with Glowing Coral Ring)
    this.centerCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    this.centerCircle.setAttribute("cx", this.cx);
    this.centerCircle.setAttribute("cy", this.cy);
    this.centerCircle.setAttribute("r", this.rIn);
    this.centerCircle.setAttribute("fill", "rgba(22, 26, 36, 0.88)");
    this.centerCircle.setAttribute("stroke", "#ff3366");
    this.centerCircle.setAttribute("stroke-width", "2");
    this.centerCircle.setAttribute("filter", "url(#pink-glow)");
    this.centerCircle.style.cursor = "pointer";

    this.centerCircle.addEventListener("click", () => {
      sfx.tick();
      const curSeg = WHEEL_SEGMENTS[activeSegIndex];
      if (curSeg.primaryAction) {
        executeAE(curSeg.primaryAction.cmd, curSeg.primaryAction.name);
      }
    });

    this.centerText = document.createElementNS("http://www.w3.org/2000/svg", "text");
    this.centerText.setAttribute("x", this.cx);
    this.centerText.setAttribute("y", this.cy + 3.5);
    this.centerText.setAttribute("fill", "#ffffff");
    this.centerText.setAttribute("text-anchor", "middle");
    this.centerText.setAttribute("font-size", "10");
    this.centerText.setAttribute("font-weight", "700");
    this.centerText.setAttribute("pointer-events", "none");

    this.centerGroup.appendChild(this.centerCircle);
    this.centerGroup.appendChild(this.centerText);
  }

  setActiveSegment(index, playSound = false) {
    if (playSound && activeSegIndex !== index) {
      sfx.tick();
    }
    activeSegIndex = index;

    // Highlight active wedge in Glowing Coral Pink
    this.slices.forEach((item, i) => {
      const isActive = (i === index);
      if (isActive) {
        item.path.setAttribute("fill", "url(#activePinkGrad)");
        item.path.setAttribute("stroke", "#ff4d79");
        item.path.setAttribute("stroke-width", "1.5");
        item.path.setAttribute("filter", "url(#pink-glow)");
        item.labelEl.setAttribute("fill", "#ffffff");
        item.labelEl.setAttribute("font-weight", "800");
      } else {
        item.path.setAttribute("fill", "rgba(34, 40, 54, 0.75)");
        item.path.setAttribute("stroke", "rgba(255, 255, 255, 0.12)");
        item.path.setAttribute("stroke-width", "1");
        item.path.removeAttribute("filter");
        item.labelEl.setAttribute("fill", "#cbd5e1");
        item.labelEl.setAttribute("font-weight", "600");
      }
    });

    const activeSeg = WHEEL_SEGMENTS[index];
    this.centerText.textContent = activeSeg.primaryAction ? activeSeg.primaryAction.name : activeSeg.label;

    // Render Concentric Curved Fan Blades (Matching Photo!)
    this.renderFanBlades(index);
  }

  renderFanBlades(index) {
    this.fanoutGroup.innerHTML = "";
    const seg = WHEEL_SEGMENTS[index];
    const sliceAngle = 360 / WHEEL_SEGMENTS.length;
    const midAngle = index * sliceAngle;

    if (seg.isGrid) {
      // 3x3 Anchor Grid Overlay
      const pos = polarToCartesian(this.cx, this.cy, this.rFanIn + 22, midAngle);
      const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
      g.setAttribute("transform", `translate(${pos.x - 32}, ${pos.y - 32})`);

      const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      rect.setAttribute("width", "64");
      rect.setAttribute("height", "64");
      rect.setAttribute("rx", "8");
      rect.setAttribute("fill", "rgba(20, 24, 34, 0.85)");
      rect.setAttribute("stroke", "rgba(255, 255, 255, 0.18)");
      rect.setAttribute("stroke-width", "1.5");
      g.appendChild(rect);

      const cells = ["TL", "TC", "TR", "ML", "MC", "MR", "BL", "BC", "BR"];
      cells.forEach((c, idx) => {
        const rx = 4 + (idx % 3) * 19;
        const ry = 4 + Math.floor(idx / 3) * 19;

        const cellRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        cellRect.setAttribute("x", rx);
        cellRect.setAttribute("y", ry);
        cellRect.setAttribute("width", "17");
        cellRect.setAttribute("height", "17");
        cellRect.setAttribute("rx", "3");
        cellRect.setAttribute("fill", c === "MC" ? "#ff3366" : "rgba(45, 52, 70, 0.7)");
        cellRect.setAttribute("stroke", c === "MC" ? "#ffffff" : "rgba(255, 255, 255, 0.15)");
        cellRect.style.cursor = "pointer";

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        text.setAttribute("x", rx + 8.5);
        text.setAttribute("y", ry + 12);
        text.setAttribute("fill", c === "MC" ? "#ffffff" : "#cbd5e1");
        text.setAttribute("text-anchor", "middle");
        text.setAttribute("font-size", "8");
        text.setAttribute("font-weight", "bold");
        text.setAttribute("pointer-events", "none");
        text.textContent = c;

        cellRect.addEventListener("click", (e) => {
          e.stopPropagation();
          executeAE(`fw_anchor("${c}")`, `Anchor ${c}`);
        });

        g.appendChild(cellRect);
        g.appendChild(text);
      });

      this.fanoutGroup.appendChild(g);
      return;
    }

    if (seg.tools && seg.tools.length > 0) {
      // Fan Blade Sectors (Concentric Curved Blocks)
      const count = seg.tools.length;
      const totalSpread = Math.min(84, count * 16);
      const startAngle = midAngle - (totalSpread / 2);
      const bladeAngle = totalSpread / count;

      seg.tools.forEach((tool, idx) => {
        const a0 = startAngle + (idx * bladeAngle);
        const a1 = a0 + bladeAngle - 1.5; // 1.5 deg gap between blades
        const bladeMid = (a0 + a1) / 2;

        const bladePath = document.createElementNS("http://www.w3.org/2000/svg", "path");
        bladePath.setAttribute("d", describeArc(this.cx, this.cy, this.rFanIn, this.rFanOut, a0, a1));
        bladePath.setAttribute("fill", "rgba(45, 52, 68, 0.75)");
        bladePath.setAttribute("stroke", "rgba(255, 255, 255, 0.18)");
        bladePath.setAttribute("stroke-width", "1");
        bladePath.style.cursor = "pointer";
        bladePath.style.transition = "fill 0.15s, stroke 0.15s";

        const textPos = polarToCartesian(this.cx, this.cy, (this.rFanIn + this.rFanOut) / 2 + 1, bladeMid);
        const textEl = document.createElementNS("http://www.w3.org/2000/svg", "text");
        textEl.setAttribute("x", textPos.x);
        textEl.setAttribute("y", textPos.y + 3);
        textEl.setAttribute("fill", "#ffffff");
        textEl.setAttribute("text-anchor", "middle");
        textEl.setAttribute("font-size", "8.5");
        textEl.setAttribute("font-weight", "600");
        textEl.setAttribute("pointer-events", "none");
        textEl.textContent = tool.name;

        // Hover effect on blade
        bladePath.addEventListener("mouseenter", () => {
          bladePath.setAttribute("fill", "rgba(255, 51, 102, 0.88)");
          bladePath.setAttribute("stroke", "#ff6b8b");
          bladePath.setAttribute("filter", "url(#pink-glow)");
          sfx.tick();
        });

        bladePath.addEventListener("mouseleave", () => {
          bladePath.setAttribute("fill", "rgba(45, 52, 68, 0.75)");
          bladePath.setAttribute("stroke", "rgba(255, 255, 255, 0.18)");
          bladePath.removeAttribute("filter");
        });

        // Click blade to fire
        bladePath.addEventListener("click", (e) => {
          e.stopPropagation();
          executeAE(tool.cmd, tool.name);
        });

        this.fanoutGroup.appendChild(bladePath);
        this.fanoutGroup.appendChild(textEl);
      });
    }
  }
}

// Startup
document.addEventListener("DOMContentLoaded", () => {
  initExtendScript();
  window.glassWheel = new GlassWheelEngine("wheel-svg-box");

  // View Switcher (Wheel vs Grid)
  const btnWheel = document.getElementById("btn-view-wheel");
  const btnGrid = document.getElementById("btn-view-grid");
  const viewWheel = document.getElementById("view-wheel");
  const viewGrid = document.getElementById("view-grid");

  if (btnWheel && btnGrid) {
    btnWheel.addEventListener("click", () => {
      btnWheel.classList.add("active");
      btnGrid.classList.remove("active");
      viewWheel.classList.remove("hidden");
      viewGrid.classList.add("hidden");
      if (window.glassWheel) {
        window.glassWheel.setActiveSegment(activeSegIndex, false);
      }
    });

    btnGrid.addEventListener("click", () => {
      btnGrid.classList.add("active");
      btnWheel.classList.remove("active");
      viewGrid.classList.remove("hidden");
      viewWheel.classList.add("hidden");
    });
  }

  // 3x3 Grid Buttons in Grid View
  document.querySelectorAll(".grid-cell").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".grid-cell").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const pos = btn.getAttribute("data-pos");
      executeAE(`fw_anchor("${pos}")`, `Anchor ${pos}`);
    });
  });

  // Action Buttons in Grid View
  function bindAction(id, cmd, name) {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener("click", () => {
        executeAE(cmd, name);
      });
    }
  }

  bindAction("btn-grid-null", "fw_nullAndParent()", "Null & Parent");
  bindAction("btn-grid-adj", "fw_createAdjustment()", "Adjustment Layer");
  bindAction("btn-grid-solid", "fw_createSolid()", "Comp Solid");
  bindAction("btn-grid-cam", "fw_createCamera()", "Camera Rig");
  bindAction("btn-grid-split", "fw_split()", "Split at CTI");
  bindAction("btn-grid-precomp", "fw_precomp()", "Pre-compose");
  bindAction("btn-grid-trimin", "fw_trimIn()", "Trim In");
  bindAction("btn-grid-trimout", "fw_trimOut()", "Trim Out");
  bindAction("btn-grid-ease", "fw_smoothEase()", "Smooth Ease 70%");
  bindAction("btn-grid-wiggle", 'fw_expression("wiggle(3, 25);")', "Wiggle Expression");
  bindAction("btn-grid-loop", 'fw_expression("loopOut(\\"cycle\\");")', "LoopOut Expression");
  bindAction("btn-grid-center", "fw_center()", "Center Layer");
  bindAction("btn-grid-purge", "fw_purge()", "Cache Purged");
});
