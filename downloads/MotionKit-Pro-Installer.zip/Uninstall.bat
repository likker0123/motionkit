@echo off
setlocal
title Uninstall MotionKit Pro
echo Removing MotionKit Pro from Adobe CEP Extensions...
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionkit.pro"
if exist "%TARGET_DIR%" (
    rmdir /S /Q "%TARGET_DIR%"
    echo [OK] MotionKit Pro has been removed.
) else (
    echo MotionKit Pro is not installed.
)
pause
