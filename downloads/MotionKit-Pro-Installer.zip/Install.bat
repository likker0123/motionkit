@echo off
setlocal
title Install MotionKit Pro v9.2.0 Master
color 0A

echo =======================================================
echo          MOTIONKIT PRO v9.2.0 MASTER INSTALLER
echo =======================================================
echo.
echo Installing MotionKit Pro into Adobe CEP Extensions...

set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionkit.pro"
if not exist "%APPDATA%\Adobe\CEP\extensions" (
    mkdir "%APPDATA%\Adobe\CEP\extensions"
)

xcopy /E /I /Y /Q "%~dp0com.motionkit.pro" "%TARGET_DIR%" >nul
if %errorlevel% neq 0 (
    echo [ERROR] Failed to copy extension files.
    pause
    exit /b 1
)

echo [OK] Files copied to: %TARGET_DIR%

echo Setting up Adobe PlayerDebugMode...
for /L %%i in (7,1,16) do (
    reg add "HKCU\Software\Adobe\CSXS.%%i" /v "PlayerDebugMode" /t REG_SZ /d "1" /f >nul 2>&1
)
echo [OK] Adobe CEP Debug Mode enabled!

echo.
echo =======================================================
echo          INSTALLATION COMPLETE SUCCESSFULLY!
echo =======================================================
echo.
echo Open Adobe After Effects and navigate to:
echo   Window ^> Extensions ^> MotionKit Pro
echo.
pause
