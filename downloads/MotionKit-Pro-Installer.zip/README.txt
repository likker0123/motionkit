=======================================================
   MOTIONKIT PRO v9.2.0 MASTER SUITE (102+ TOOLS)
=======================================================

Installation Instructions:
1. Double-click "Install.bat" to automatically install the extension.
2. Start Adobe After Effects.
3. Open from the top menu:
   Window > Extensions > MotionKit Pro

Activation:
- On first launch, the panel will display your unique Machine ID.
- Copy your Machine ID and generate your License Key using MotionKit-License-Keygen.html on your Desktop.
- Paste the key and click "Activate License".
- For instant VIP access, enter: MOTIONKIT-MASTER-LIFETIME-ACCESS
