@echo off
title Flex GUI Pro Installer
color 0B
echo ======================================================
echo          FLEX GUI PRO - 1-CLICK INSTALLER
echo ======================================================
echo.
echo [1/2] Windows Registry PlayerDebugMode enable kiya ja raha hai...
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.7" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.8" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d "1" /f >nul 2>&1
echo [OK] Registry settings enabled!
echo.
echo [2/2] Files ko Adobe CEP extensions folder me copy kiya ja raha hai...
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.captureflex.flexguipro"
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
xcopy /s /e /y "%~dp0com.captureflex.flexguipro\*" "%DEST%\" >nul
echo [OK] Extension successfully installed!
echo.
echo ======================================================
echo   Flex GUI Pro Dusre PC me successfully install ho gaya!
echo.
echo   Adobe After Effects ko open/restart karein:
echo   Window > Extensions > Flex GUI Pro
echo ======================================================
echo.
pause