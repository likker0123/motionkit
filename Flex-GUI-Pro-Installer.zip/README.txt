﻿FLEX GUI PRO - INSTALLATION GUIDE (FOR OTHER PC)
=================================================

METHOD 1: (Sabse Aasan - 1 Click)
---------------------------------
1. Is pure folder / zip ko extract karke dusre PC me le jayein (Pen drive, Drive, etc.).
2. 'Install.bat' file par right-click karke Run as Administrator ya double-click karein.
3. Adobe After Effects open/restart karein.
4. Top menu me jayein: Window > Extensions > Flex GUI Pro.

METHOD 2: (Manual Copy Paste)
-----------------------------
1. 'com.captureflex.flexguipro' folder ko copy karein.
2. Dusre PC me Windows + R dabayein aur ye paste karke Enter karein:
   %APPDATA%\Adobe\CEP\extensions\
   (Agar folder na ho toh 'Adobe' ke andar 'CEP', aur usme 'extensions' bana lein).
3. Yahan 'com.captureflex.flexguipro' folder ko paste kar dein.
4. CMD (Command Prompt) open karein aur ye command run karein (Debug mode ke liye):
   reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
   reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d "1" /f
5. After Effects open karein: Window > Extensions > Flex GUI Pro.